// Shell de la aplicación: rutas por hash, menú, estadísticas, ajustes y copia de seguridad.
import { traducirCopia } from './core/migrar_ids.js';   // debe ir primero: traslada los datos guardados a los nuevos identificadores
import { JUEGOS, CATEGORIAS, PROXIMAMENTE, GRUPOS, entradas } from './registry.js';
import { $, el, esc, fmtTiempo } from './core/dom.js';
import * as store from './core/storage.js';
import * as aj from './core/ajustes.js';
import * as stats from './core/stats.js';
import * as son from './core/sonido.js';
import { BARAJAS, urlTapete, buscarFondo, cargarBarajas, precargarSeleccion } from './core/cartas.js';
import * as logros from './core/logros.js';
import { conSemilla, conSemillaAsync, hoy, fechaLarga } from './core/semilla.js';
import { VERSION } from './version.js';
import { TUTORIALES } from './tutoriales/indice.js';

// «Palabras Cruzadas» (el nombre más largo) ocupa justo la zona clara del banner (50 % de su ancho); los demás, más cortos, caben siempre
function ajustarCabecera() {
  const h = document.getElementById('titulo'); if (!h || !h.clientWidth) return;
  const m = document.createElement('span'); m.style.cssText = 'position:absolute;visibility:hidden;white-space:nowrap;font:900 100px Fraunces,Georgia,serif;letter-spacing:-.02em'; m.textContent = 'Palabras Cruzadas';
  document.body.appendChild(m); const w = m.getBoundingClientRect().width; m.remove(); if (!w) return;
  h.style.setProperty('--tit-fs', Math.min(0.5 * h.clientWidth / w * 100, h.clientHeight * 0.78).toFixed(1) + 'px');
}
// En el móvil, al desplazar la página la barra del navegador se oculta/aparece y se dispara «resize» (solo cambia un poco el alto).
// Los juegos recalculan su tamaño con ese evento y el contenido se recoloca: la página «salta». Se ignoran esos cambios pequeños de alto.
{
  const addOrig = window.addEventListener.bind(window), remOrig = window.removeEventListener.bind(window), env = new WeakMap();
  window.addEventListener = function (tipo, fn, op) {
    if (tipo !== 'resize' || typeof fn !== 'function') return addOrig(tipo, fn, op);
    let w = innerWidth, h = innerHeight;
    const f = function (e) { if (innerWidth === w && Math.abs(innerHeight - h) < 130) return; w = innerWidth; h = innerHeight; return fn.call(this, e); };
    env.set(fn, f); return addOrig(tipo, f, op);
  };
  window.removeEventListener = function (tipo, fn, op) { return remOrig(tipo, tipo === 'resize' && env.has(fn) ? env.get(fn) : fn, op); };
}
window.addEventListener('resize', ajustarCabecera); ajustarCabecera();
if (document.fonts) { document.fonts.load('900 40px Fraunces').then(ajustarCabecera).catch(() => {}); document.fonts.ready.then(ajustarCabecera); }
const imgIc = (n, w = 22, c = 'ic') => `<img class="${c}" src="img/iconos/${n}.webp" alt="" width="${w}" height="${w}">`;   // icono ilustrado (img/iconos)
const emblema = (id, w = 46) => `<img class="emb" src="img/sellos/${id}.webp" alt="" width="${w}" height="${w}" loading="lazy">`;   // emblema de un juego (img/sellos)
// Los botones que empiezan por un emoji conocido (💡 Pista, ↶ Deshacer, 🏆 Podio…) se muestran con su icono ilustrado, en todos los juegos.
const ICONOS_BTN = { '💡': 'pista', '↶': 'deshacer', '↩️': 'deshacer', '↩': 'deshacer', '🏆': 'podio', '🎨': 'apariencia', '📖': 'reglas', '📤': 'compartir' };
let iconizando = false, iconizarPend = false;
function iconizar() {
  iconizarPend = false; iconizando = true;
  try {
    document.querySelectorAll('button:not([data-sin-ic]), .btn:not([data-sin-ic])').forEach(b => {
      const n = b.firstChild; if (!n || n.nodeType !== 3) return;
      const t = n.nodeValue.trimStart(), k = Object.keys(ICONOS_BTN).find(e => t.startsWith(e)); if (!k) return;
      const im = document.createElement('img'); im.className = 'ic'; im.alt = ''; im.width = im.height = 22; im.src = 'img/iconos/' + ICONOS_BTN[k] + '.webp';
      n.nodeValue = ' ' + t.slice(k.length).trimStart(); b.insertBefore(im, n);
    });
  } finally { iconizando = false; }
}
new MutationObserver(() => { if (iconizando || iconizarPend) return; iconizarPend = true; requestAnimationFrame(iconizar); }).observe(document.body, { childList: true, subtree: true, characterData: true });
// Título de la cabecera: «JugamiGO» con el sello GO; en cada juego, su nombre en tinta
const cabTxt = (t, href = '') => {
  const e = document.getElementById('titulotxt'); if (!e) return;
  e.style.color = '';
  if (href) { const a = document.createElement('a'); a.className = 'cab-inicio'; a.href = href; a.textContent = t; a.setAttribute('aria-label', t + ': ver los juegos de su categoría'); e.replaceChildren(a); return; }
  if (t === 'JugamiGO') { e.innerHTML = '<a class="cab-inicio" href="#/" aria-label="JugamiGO: ir a la pantalla de inicio">Jugami<span class="go">GO</span></a>'; return; }
  e.textContent = t;
};
let nombreVista = '';       // nombre de la pantalla actual (título de la hoja de opciones); la cabecera es fija
const app = $('#app'), nav = $('#nav');
// En Estadísticas y Ajustes el scroll va dentro de <main> (la página no se desplaza), así las barras del navegador móvil no cambian el tamaño de la pantalla ni mueven el fondo.
const scrollInterno = () => document.body.classList.contains('fondo') || document.body.classList.contains('jfondo');
const leerScroll = () => scrollInterno() ? app.scrollTop : scrollY;
const ponerScroll = y => { if (scrollInterno()) app.scrollTop = y; else scrollTo(0, y); };
const RUTAS = [
  ['cat-logica', 'img:ruta-logica', 'Lógica', '#/cat/logica'],
  ['cat-tablero', 'img:ruta-tablero', 'Tablero', '#/cat/tablero'],
  ['cat-cartas', 'img:ruta-cartas', 'Cartas', '#/cat/cartas'],
  ['cat-palabras', 'img:ruta-palabras', 'Palabras', '#/cat/palabras'],
  ['cat-arcade', 'img:ruta-arcade', 'Arcade', '#/cat/arcade'],
  ['stats', '📖', 'Diario', '#/stats'],
  ['ajustes', '⚙️', 'Ajustes', '#/ajustes']
];
let actual = null, token = 0, menuItems = [];
// Antes había un menú ⋯ en la cabecera. Ahora «Reglas» va en la barra inferior y el resto de entradas (Historial, Pista, Podio, Compartir…) se abren desde «Pausa / Salir» → «Más opciones».
const RE_REGLAS = /^(Reglas|Reglamento|Cómo se juega)/i, RE_EN_BARRA = /Apariencia|^(Nuev[oa]\b|Otra palabra)|^⏸️ Pausa/i;
const itemReglas = () => menuItems.find(it => RE_REGLAS.test(it.texto));
const itemsExtra = () => menuItems.filter(it => !RE_REGLAS.test(it.texto) && !RE_EN_BARRA.test(it.texto));
const V1_KEY = 'juegos-reunidos-save';

aj.aplicarTema();
const CAT_IDS = Object.fromEntries(Object.keys(CATEGORIAS).map(k => [k, JUEGOS.filter(j => j.categoria === k).map(j => j.id)]));
// Si el almacenamiento del navegador está lleno, se avisa (antes la partida dejaba de guardarse sin decir nada).
let ultAvisoLleno = 0;
store.siFalla(() => { if (Date.now() - ultAvisoLleno > 15000) { ultAvisoLleno = Date.now(); setTimeout(() => aviso('⚠️ No se pudo guardar: el almacenamiento del navegador está lleno. Borra partidas en Ajustes.'), 0); } });

/* ---------- utilidades de interfaz ---------- */
function aviso(texto, ms = 2400) {
  document.querySelectorAll('.toast').forEach(x => x.remove());
  const t = el('div', { class: 'toast', role: 'status' }, texto);
  document.body.append(t); setTimeout(() => t.remove(), ms);
}
window.addEventListener('offline', () => { import('./core/resultado.js').then(m => m.mostrarResultado({ res: 'offline' })).catch(() => {}); });
// Avisos de logros nuevos (uno detrás de otro)
function avisarLogros(nuevos) { nuevos.forEach((d, k) => setTimeout(() => { aviso(`🏅 Logro: ${d.nombre}`, 2800); son.play('ganar'); }, 600 + k * 3000)); }
const revisarLogros = () => avisarLogros(logros.revisar(CAT_IDS));
// Pedir un texto con la hoja modal (nombres del podio, palabra secreta del Ahorcado…). Devuelve null si se cancela.
function pedirTexto(titulo, { valor = '', max = 14, nota = '', tipo = 'text', placeholder = '' } = {}) {
  return new Promise(res => {
    const area = tipo === 'area';                                // texto largo de varias líneas (p. ej. un PGN)
    const inp = area ? el('textarea', { class: 'pedir', rows: '8', maxlength: String(max), placeholder, spellcheck: 'false', 'aria-label': titulo })
      : el('input', { class: 'pedir', type: tipo, maxlength: String(max), value: valor, placeholder, autocomplete: 'off', 'aria-label': titulo });
    if (area) inp.value = valor;
    let hecho = false, cerrar;
    const fin = v => { if (hecho) return; hecho = true; cerrar(); res(v); };
    const ok = el('button', { class: 'btn on', type: 'button', onclick: () => fin(inp.value) }, 'Aceptar');
    const no = el('button', { class: 'btn', type: 'button', onclick: () => fin(null) }, 'Cancelar');
    inp.addEventListener('keydown', e => { if (e.key === 'Enter' && !area) { e.preventDefault(); fin(inp.value); } });
    cerrar = hoja([el('h2', {}, titulo), nota ? el('p', { class: 'note' }, nota) : null, inp, el('div', { class: 'bar', style: 'margin-top:12px' }, no, ok)], () => fin(null));
    setTimeout(() => { inp.focus(); inp.select(); }, 60);
  });
}
// Compartir un texto: hoja del sistema si existe; si no, al portapapeles.
async function compartir(texto) {
  const url = location.href.split('#')[0];
  try {
    if (navigator.share) { await navigator.share({ title: 'JugamiGO', text: texto, url }); return; }
  } catch (e) { if (e && e.name === 'AbortError') return; }
  try { await navigator.clipboard.writeText(texto + '\n' + url); aviso('📋 Copiado: pégalo donde quieras'); }
  catch { modal('Compartir', `<p>Copia este texto:</p><p><b>${esc(texto)}</b><br>${esc(url)}</p>`); }
}
/* Las ventanas emergentes se integran con el botón «Atrás» del móvil: al abrir una se añade una entrada al historial,
   y «Atrás» cierra la ventana (en vez de salir del juego). Si se cierra con un botón, esa entrada se retira. */
const pilaModales = []; let saltosHist = 0, idModal = 0;
window.addEventListener('popstate', e => {
  if (saltosHist > 0) { saltosHist--; return; }                              // retroceso hecho por nosotros mismos
  if (pilaModales.length) { pilaModales[pilaModales.length - 1].cerrar(true); return; }   // «Atrás» con una ventana abierta: la cierra
  if (e.state && e.state.jrModal) { saltosHist++; history.back(); }        // entrada de una ventana ya cerrada: se salta
});
function hoja(contenido, alCerrar = null) {
  const m = el('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true' }, el('div', { class: 'hoja' }, contenido));
  let cerrada = false; const id = ++idModal;
  const cerrar = viaAtras => { if (cerrada) return; cerrada = true; m.remove(); document.removeEventListener('keydown', esc_);
    const i = pilaModales.findIndex(x => x.id === id); if (i >= 0) pilaModales.splice(i, 1);
    if (viaAtras !== true) setTimeout(() => { if (history.state && history.state.jrModal === id) { saltosHist++; history.back(); } }, 0);   // retira la entrada (si no se ha navegado a otra pantalla)
    if (alCerrar) alCerrar(); };
  const esc_ = e => { if (e.key === 'Escape' && [...document.querySelectorAll('.modal')].pop() === m) cerrar(); };   // con ventanas apiladas, Esc cierra solo la de encima
  m.addEventListener('click', e => { if (e.target === m) cerrar(); });
  document.addEventListener('keydown', esc_);
  document.body.append(m);
  try { history.pushState({ jrModal: id }, ''); pilaModales.push({ id, cerrar }); } catch (e) {}
  return cerrar;
}
function modal(titulo, html) {
  const cuerpo = el('div', { class: 'cuerpo' }); cuerpo.innerHTML = html;
  const b = el('button', { class: 'btn on', style: 'margin-top:12px' }, 'Cerrar');
  const cerrar = hoja([el('h2', {}, titulo), cuerpo, b]); b.addEventListener('click', cerrar);
  return { cuerpo, cerrar };
}
function abrirMenu(lista) {
  if (!lista || !lista.length) return;
  let cerrar;
  const items = lista.map(it => el('button', { class: 'item' + (it.peligro ? ' danger' : ''), 'aria-pressed': it.activo == null ? false : String(!!it.activo), onclick: () => { cerrar(); it.accion(); } }, it.texto));
  cerrar = hoja([el('h2', {}, nombreVista), ...items]);
}

/* ---------- API que reciben los juegos ---------- */
function crearApi(j, ent, mod, root) {
  const id = j.id;
  let abrirAsp = null, defBarra = null;
  // Barra inferior común (Nuevo panel / Configurar / Apariencia / Pausa-Salir): cada juego la pide con api.barraHtml() al final de su pantalla de partida.
  const PANEL = ['sopaletras', 'crucigramas', 'elrosco', 'ruletamillonaria', 'encadenadas', 'numerosyletras', 'elahorcado'];
  let celebrada = 0;
  function selloVictoria() { const T = stats.todas(); return { id, n: Object.values(T).reduce((a, s) => a + (s && s.victorias || 0), 0), juego: (JUEGOS.find(j => j.id === id) || {}).nombre || '' }; }
  function victoria() {
    if (aj.ajustes().celebrar === false || Date.now() - celebrada < 3000) return;
    celebrada = Date.now();
    setTimeout(() => {
      if (!root.isConnected) return;
      import('./core/victoria.js').then(m => { if (root.isConnected) m.celebrar({ sello: selloVictoria(), etiqueta: etiquetaNueva(), nueva: defBarra && defBarra.nueva ? () => defBarra.nueva() : null }); }).catch(() => {});
    }, 900);
  }
  let ultRes = 0;
  function resultadoSuave(res, primero) {          // derrota o tablas: tarjeta pequeña con Goli (se respeta «Celebrar al ganar» = no)
    if (aj.ajustes().celebrar === false || Date.now() - ultRes < 3000) return;
    ultRes = Date.now();
    setTimeout(() => { if (!root.isConnected) return; import('./core/resultado.js').then(m => { if (root.isConnected) m.mostrarResultado({ res, primero, juego: j.nombre, nueva: defBarra && defBarra.nueva ? () => defBarra.nueva() : null, etiqueta: etiquetaNueva() }); }).catch(() => {}); }, 700);
  }
  const etiquetaNueva = () => (defBarra && defBarra.etiqueta) || (j.categoria === 'logica' || PANEL.includes(id) ? 'Nuevo panel' : 'Nueva partida');
  // Pausa: el juego puede dar `pausar()/reanudar()` propios y/o `crono: () => cronómetro` (se para y se reanuda solo si estaba en marcha).
  const parar_ = () => {
    let c = null, activo = false;
    try { c = defBarra && defBarra.crono ? defBarra.crono() : null; activo = !!(c && c.activo); if (activo) c.pausar(); defBarra && defBarra.pausar && defBarra.pausar(); } catch (e) { console.error(e); }
    return origen => { try { if (activo && c && !c.activo) c.iniciar(); defBarra && defBarra.reanudar && defBarra.reanudar(origen); } catch (e) { console.error(e); } };
  };
  const pausaTemp = fn => { const seguir = parar_(); fn(() => seguir('aux')); };
  // Tutorial del juego (js/tutoriales/<id>.js): ventana con pasos; se pausa la partida mientras dura.
  async function lanzarTutorial() {
    if (!TUTORIALES[id]) return;
    try {
      const [mt, core] = await Promise.all([TUTORIALES[id](), import('./core/tutorial.js')]);
      if (!document.getElementById('cssTutorial')) { const l = el('link', { rel: 'stylesheet', href: 'css/tutorial.css', id: 'cssTutorial' }); l.dataset.juego = '*'; document.head.append(l); }
      pausaTemp(volver => {
        let cerrar; const cont = core.crearTutorial(mt.TUTORIAL, { cerrar: () => cerrar && cerrar(), hecho: () => aj.setPref(id, '_tutoHecho', true) });
        cerrar = hoja([cont], volver);
      });
    } catch (e) { console.error(e); aviso('No se pudo abrir el tutorial.'); }
  }
  // Primera vez en el juego (sin partida guardada): se ofrece el tutorial como mucho dos veces.
  function ofrecerTutorial() {
    if (!TUTORIALES[id] || aj.pref(id, '_tutoHecho', false) || (aj.pref(id, '_tutoOf', 0) || 0) >= 2 || ent) return;
    setTimeout(() => {
      if (!root.isConnected) return;
      aj.setPref(id, '_tutoOf', (aj.pref(id, '_tutoOf', 0) || 0) + 1);
      let cerrar;
      const b1 = el('button', { class: 'btn on', style: 'margin:4px', onclick: () => { cerrar(); lanzarTutorial(); } }, '🎓 Sí, enséñame'),
        b2 = el('button', { class: 'btn', style: 'margin:4px', onclick: () => cerrar() }, 'Ahora no'),
        b3 = el('button', { class: 'btn', style: 'margin:4px', onclick: () => { aj.setPref(id, '_tutoOf', 9); cerrar(); } }, 'No preguntar más');
      cerrar = hoja([el('h2', {}, '🎓 ¿Quieres un tutorial rápido?'), el('p', { class: 'note' }, `Te explico cómo se juega a ${j.nombre} paso a paso, con ejercicios cortos. Lo tendrás siempre en «Reglas».`), el('div', { style: 'display:flex;flex-wrap:wrap;justify-content:center' }, b1, b2, b3)]);
    }, 700);
  }
  function abrirConfig() {
    const c = defBarra && defBarra.config; if (!c) return;
    if (c.pantalla) { c.pantalla(); return; }       // el juego usa su propia pantalla de configuración (la inicial)
    pausaTemp(volver => {
      const vals = { ...c.valores() }, cont = el('div', { class: 'cfg-cont' });
      let aplicado = false, cerrar;
      const pintar = () => {
        cont.replaceChildren(...c.grupos(vals).filter(g => g.visible !== false).map(g => el('div', { class: 'cfg-g' }, el('span', { class: 'lbl' }, g.titulo),
          g.desplegable
            ? el('select', { class: 'desplegable', 'data-ks': g.clave, 'aria-label': g.titulo }, ...g.opciones.map(([v, l]) => el('option', { value: JSON.stringify(v), selected: String(vals[g.clave]) === String(v) }, l)))
            : el('div', { class: 'seg' }, ...g.opciones.map(([v, l]) => el('button', { type: 'button', class: 'btn' + (String(vals[g.clave]) === String(v) ? ' on' : ''), 'data-k': g.clave, 'data-v': JSON.stringify(v) }, l))),
          g.nota ? el('small', { class: 'note' }, g.nota) : null)));
      };
      cont.addEventListener('click', e => {
        const b = e.target.closest('button[data-k]'); if (!b) return;
        vals[b.dataset.k] = JSON.parse(b.dataset.v); if (c.alCambiar) c.alCambiar(vals, b.dataset.k); pintar();
      });
      cont.addEventListener('change', e => { const sl = e.target.closest('select[data-ks]'); if (!sl) return; vals[sl.dataset.ks] = JSON.parse(sl.value); if (c.alCambiar) c.alCambiar(vals, sl.dataset.ks); pintar(); });
      pintar();
      const emp = el('button', { class: 'btn on', onclick: () => { aplicado = true; cerrar(); c.aplicar({ ...vals }); } }, '▶️ ' + etiquetaNueva());
      cerrar = hoja([el('h2', {}, '⚙️ Configurar partida'), el('p', { class: 'note' }, c.nota || 'Elige las opciones y empieza una partida nueva. La partida actual se abandona.'), cont,
        el('div', { class: 'bar', style: 'margin-top:14px' }, el('button', { class: 'btn', onclick: () => cerrar() }, 'Cancelar'), emp)], () => { if (!aplicado) volver(); });
    });
  }
  function preguntarSalir() {
    const seguir = parar_();
    let decidido = false, cerrar;
    const no = el('button', { class: 'btn on', onclick: () => { decidido = true; cerrar(); seguir('salir'); } }, 'No, seguir jugando');
    const si = el('button', { class: 'btn', onclick: () => { decidido = true; cerrar(); if (defBarra && defBarra.salir) defBarra.salir(); else location.hash = j.categoria ? '#/cat/' + j.categoria : '#/'; } }, 'Sí, salir');
    const extra = itemsExtra();
    const mas = extra.length ? el('button', { class: 'btn', style: 'width:100%;margin-top:10px', onclick: () => { decidido = true; cerrar(); seguir('salir'); setTimeout(() => abrirMenu(extra), 0); } }, '⋯ Más opciones del juego') : null;
    cerrar = hoja([el('h2', {}, '⏸️ Partida en pausa'), el('p', {}, '¿Salir de la partida?'), el('div', { class: 'bar', style: 'margin-top:14px' }, si, no), mas], () => { if (!decidido) seguir('salir'); });
  }
  return {
    barra(def) { defBarra = def; },
    barraHtml() {
      return `<div class="barra-gen" role="group" aria-label="Controles de la partida"><button type="button" data-gen="nueva"><span aria-hidden="true">🆕</span>${esc(etiquetaNueva())}</button><button type="button" data-gen="config"><span aria-hidden="true">⚙️</span>Configurar partida</button>${abrirAsp ? '<button type="button" data-gen="aspecto"><span aria-hidden="true">🎨</span>Apariencia</button>' : ''}<button type="button" data-gen="reglas"><span aria-hidden="true">📖</span>Reglas</button><button type="button" data-gen="salir"><span aria-hidden="true">⏸️</span>Pausa / Salir</button></div>`;
    },
    gen(ac) {
      if (!defBarra) return;
      if (ac === 'nueva') { if (defBarra.nueva) defBarra.nueva(); }
      else if (ac === 'config') abrirConfig();
      else if (ac === 'aspecto') { if (abrirAsp) pausaTemp(volver => abrirAsp(volver)); }
      else if (ac === 'reglas') {
        const r = itemReglas();
        if (!TUTORIALES[id]) { if (r) r.accion(); return; }
        // Con tutorial: se elige entre leer las reglas o hacerlo
        let cerrar; const b1 = el('button', { class: 'item', onclick: () => { cerrar(); if (r) r.accion(); } }, '📖 Ver las reglas'), b2 = el('button', { class: 'item', onclick: () => { cerrar(); lanzarTutorial(); } }, '🎓 Hacer el tutorial (paso a paso)');
        cerrar = hoja([el('h2', {}, nombreVista), b2, ...(r ? [b1] : [])]);
      }
      else if (ac === 'salir') preguntarSalir();
    },
    id, root, tutorial: () => lanzarTutorial(), ofrecerTutorial,
    cargar() { if (!ent) return null; try { return mod.validar(ent.datos) || null; } catch { return null; } },
    guardar: (datos, resumen = null, fin = false) => store.setJuego(id, datos, resumen, fin),
    borrar: () => store.borrarJuego(id),
    registrar: r => {
      const primero = !((stats.todas()[id] || {}).partidas);
      stats.registrar(id, r); revisarLogros();
      if (r && r.res === 'victoria') victoria();
      else if (r && (r.res === 'derrota' || r.res === 'tablas')) resultadoSuave(r.res, primero);
    },
    // Victoria: mensaje y animación al azar con el botón de nueva partida (core/victoria.js), común a todos los juegos.
    // Se lanza sola con registrar({ res: 'victoria' }); los modos sin CPU (2 jugadores) que no puntúan llaman a api.victoria() al acabar con ganador.
    victoria,
    record: variante => stats.record(id, variante),
    pref: (k, d) => aj.pref(id, k, d), setPref: (k, v) => aj.setPref(id, k, v),
    sonido: son.play, vibrar: son.vibrar,
    confirmar: txt => window.confirm(txt),
    aviso, modal, pedirTexto,
    compartir: texto => compartir(texto),
    titulo: t => { nombreVista = t; },
    // El menú de cada juego lleva al final «Compartir resultado» (texto del resumen de la partida guardada).
    menu(items) {
      menuItems = (items || []).slice();
      if (menuItems.length) menuItems.push({ texto: '📤 Compartir resultado', accion: () => {
        const r = store.getResumen(id);
        compartir(`${j.icono} ${j.nombre}${r && r.resumen ? ': ' + r.resumen + (r.fin ? '' : ' (en juego)') : ''} · JugamiGO`);
      } });
    },
    // Reto del día: el mismo tablero para todo el mundo (generado con semilla fecha + juego)
    reto: {
      fecha: () => hoy(),
      texto: f => fechaLarga(f || hoy()),
      generar: (fn, f = hoy()) => conSemilla(`${f}:${id}`, fn),
      generarAsync: (fn, f = hoy()) => conSemillaAsync(`${f}:${id}`, fn),
      hecho: (f = hoy()) => logros.retoHecho(f, id),
      completar(f = hoy()) {
        if (logros.retoHecho(f, id)) return false;
        logros.marcarReto(f, id); revisarLogros(); return true;
      },
    },
    // Tabla local de los 10 mejores (juegos arcade). menos=true: gana el valor más bajo (tiempos).
    podio: {
      lista: v => { const P = store.leer('podio:' + id, {}) || {}; return Array.isArray(P[v]) ? P[v] : []; },
      entra(v, valor, menos = false) { const l = this.lista(v); return valor > 0 && (l.length < 10 || (menos ? valor < l[l.length - 1].p : valor > l[l.length - 1].p)); },
      async anotar(v, valor, menos = false) {
        if (!this.entra(v, valor, menos)) return -1;
        const n = await pedirTexto('🏆 ¡Entras en el podio!', { valor: aj.pref('_', 'nombre', ''), nota: 'Escribe tu nombre para la tabla de los 10 mejores.', placeholder: 'Tu nombre' });
        const nombre = (n == null ? '' : n).trim().slice(0, 14) || 'Anónimo';
        if (n != null && n.trim()) aj.setPref('_', 'nombre', nombre);
        const P = store.leer('podio:' + id, {}) || {}, l = Array.isArray(P[v]) ? P[v] : [], f = Date.now();
        l.push({ n: nombre, p: valor, f }); l.sort((a, b) => (menos ? a.p - b.p : b.p - a.p) || a.f - b.f);
        P[v] = l.slice(0, 10); store.escribir('podio:' + id, P);
        return P[v].findIndex(x => x.f === f);
      },
      html(v, { formato = x => x.toLocaleString('es-ES'), marcar = -1 } = {}) {
        const l = this.lista(v); if (!l.length) return '<p class="note">Todavía no hay puntuaciones.</p>';
        return `<ol class="podio">${l.map((x, k) => `<li class="${k === marcar ? 'yo' : ''}"><span>${['oro', 'plata', 'bronce'][k] ? `<img class="pd-m" src="img/podio/${['oro', 'plata', 'bronce'][k]}.webp" alt="${k + 1}.º" width="22" height="26">` : k + 1 + '.'}</span><b>${esc(x.n)}</b><i>${formato(x.p)}</i><small>${new Date(x.f).toLocaleDateString('es-ES')}</small></li>`).join('')}</ol>`;
      },
    },
    aspecto(defs, alCambiar) {
      // `elec` = lo elegido y guardado (puede ser «azar»); `vals` = lo que se aplica de verdad (data-<clave> y asp.valores).
      defs = defs.filter(g => g.opciones.some(o => !o.azar && !o.nada) || !g.opciones.some(o => o.azar));   // sin imágenes que sortear, el grupo se oculta
      // Grupos propios «Forma de las fichas» (enEstilos) se integran en el desplegable «Estilos de Fichas» si el juego lo tiene.
      defs.forEach(g => { if (g.clave === 'vista') g.oculto = true; });                // 2D/3D: ya está el botón flotante de la esquina superior izquierda
      // `junto: clave` = este grupo se une, como subgrupo, al desplegable de otro grupo (p. ej. los edificios 2D y 3D de Magnate).
      defs.filter(g => g.junto).forEach(g => { const d = defs.find(x => x.clave === g.junto); if (d) { d.sub = d.sub || [d]; d.sub.push(g); g.oculto = true; } });
      // «Tapete y Tablero»: el tapete (imagen de fondo) y el color del tablero (grupos marcados con `tt`) comparten un único desplegable.
      const tts = defs.filter(g => g.tt).sort((x, y) => (/tapete|mesa/.test(y.clave) ? 1 : 0) - (/tapete|mesa/.test(x.clave) ? 1 : 0));
      if (tts.length > 1) { tts.forEach(g => { if (!g.etiqueta) g.etiqueta = /tapete|mesa/.test(g.clave) ? 'Tapete' : 'Tablero'; }); tts[0].sub = tts; tts[0].titulo = tts[0].ttTitulo || 'Tapete y Tablero'; tts[0].icono = '🖼️'; tts.slice(1).forEach(g => { g.oculto = true; }); }
      const est = defs.find(g => g.sub && g.estilos);
      if (est) defs.filter(g => g.enEstilos).forEach(g => { est.sub.splice(Math.min(1, est.sub.length), 0, g); g.oculto = true; });
      const gd = aj.pref(id, 'aspecto', {}) || {}, elec = {}, vals = {};
      const resolver = nuevo => defs.forEach(g => {
        if (elec[g.clave] !== 'azar') { vals[g.clave] = elec[g.clave]; return; }
        if (!nuevo && vals[g.clave]) return;
        const az = g.opciones.find(o => o.azar), l = g.opciones.filter(o => !o.azar && !o.nada && (!az || !az.solo || az.solo.includes(o.id))), c = l.length > 1 ? l.filter(o => o.id !== vals[g.clave]) : l;   // distinta de la anterior
        vals[g.clave] = c[Math.random() * c.length | 0].id;
      });
      // Grupo con `sel` («Fondo de Tablero»): la imagen elegida va a --tapete-url y una regla de <style> la pone detrás del tablero del juego.
      const gFs = defs.filter(g => g.sel !== undefined), gF = gFs[0];
      let stF = document.getElementById('jr-tapete-sel'); if (!stF) { stF = document.createElement('style'); stF.id = 'jr-tapete-sel'; document.head.append(stF); }
      stF.textContent = gFs.filter(g => g.sel).map((g, k, arr) => { const despues = gFs.slice(gFs.indexOf(g) + 1).map(x => `:not([data-${x.clave}^="t-"])`).join(''); return `.juego[data-${g.clave}^="t-"]${despues}${g.sel === 'raiz' ? '' : ' ' + g.sel}{background:var(--tapete-url) center/cover no-repeat!important;padding:6px;box-sizing:border-box;border-radius:14px}`; }).join('\n');
      const poner = () => {
        defs.forEach(g => { root.dataset[g.clave] = vals[g.clave]; }); precargarSeleccion(vals);
        let t = null; for (const g of gFs) { const x = buscarFondo(vals[g.clave]); if (x) t = x; }       // «Fondo de Pantalla» (último grupo) pasa por delante del «Tapete»
        if (t) root.style.setProperty('--tapete-url', `url("${urlTapete(t)}")`); else root.style.removeProperty('--tapete-url');
      };
      defs.forEach(g => { elec[g.clave] = g.opciones.some(o => o.id === gd[g.clave]) ? gd[g.clave] : g.def; });
      resolver(true); poner();
      const guardar = () => aj.setPref(id, 'aspecto', { ...elec });
      const refrescarVista = () => { if (btnVista) { const es3 = vals.vista === '3d'; btnVista.textContent = es3 ? '🔲 Ver en 2D' : '🧊 Ver en 3D'; btnVista.setAttribute('aria-label', es3 ? 'Cambiar a la vista 2D' : 'Cambiar a la vista 3D'); } };
      quitarVista();
      if (defs.some(g => g.clave === 'vista')) {
        btnVista = el('button', { type: 'button', class: 'btn vista-flot' }); document.body.append(btnVista); root.classList.add('con-vista'); posVista(); refrescarVista();
        btnVista.addEventListener('click', () => { elec.vista = vals.vista === '3d' ? '2d' : '3d'; delete vals.vista; resolver(false); poner(); guardar(); refrescarVista(); if (alCambiar) alCambiar({ ...vals }); });
      }
      // 🎨 Apariencia (igual en todos los juegos): una ventana con una sección desplegable por grupo (se abre una a la vez).
      // Cada sección muestra sus opciones como botones, muestras de color, iconos o miniaturas de imagen, según el grupo.
      const abrir = (alCerrarV) => {
        const boton = (g, o) => el('button', { type: 'button', class: 'btn ap-o' + (o.emoji ? ' ap-e' : '') + (elec[g.clave] === o.id ? ' on' : ''), 'data-g': g.clave, 'data-o': o.id, ...(o.emoji || g.soloColor ? { title: o.nombre, 'aria-label': o.nombre } : {}) },
          ...(o.emoji ? [o.emoji] : [...(o.sw || []).map(c => el('i', { class: 'sw', style: `background:${c}` })), ...(g.soloColor ? [] : [o.nombre])]));
        const actual = g => g.opciones.find(x => x.id === elec[g.clave]) || g.opciones[0];
        const resumenSec = new Map();
        const pintarResumen = g => {
          const o = actual(g), r = resumenSec.get(g.clave); if (!r) return;
          if (g.sub) { r.replaceChildren(el('span', { class: 'ap-li' }, g.icono || '🎨'), el('b', {}, g.titulo), el('small', {}, g.sub.map(sg => { const x = actual(sg); return (x.emoji ? x.nombre.replace(x.emoji, '').trim() : x.nombre) || x.nombre; }).join(' · '))); return; }
          if (g.multi) { r.replaceChildren(el('span', { class: 'ap-li' }, g.icono || '🎨'), el('b', {}, g.titulo), el('small', { class: 'ap-mres' }, ...g.multi.map(sg => { const x = sg.opciones.find(q => q.id === elec[sg.clave]); return x && x.sw ? el('i', { class: 'sw', style: `background:${x.sw[0]}` }) : el('i', { class: 'sw orig' }, '↩'); }))); return; }
          const ico = g.icono ? el('span', { class: 'ap-li' }, g.icono) : o.emoji ? el('span', { class: 'ap-li' }, o.emoji) : o.sw ? el('span', { class: 'ap-lsw' }, ...o.sw.map(c => el('i', { class: 'sw', style: `background:${c}` }))) : el('span', { class: 'ap-li' }, '🎨');
          r.replaceChildren(ico, el('b', {}, g.titulo), el('small', {}, g.soloColor && o.sw ? '' : o.emoji ? o.nombre.replace(o.emoji, '').trim() || o.nombre : o.nombre));
        };
        const elegir = (g, idO) => { elec[g.clave] = idO; delete vals[g.clave]; resolver(false); poner(); guardar(); refrescarVista(); pintarResumen(g); const r = alCambiar && alCambiar({ ...vals }); if (r && r.volver) { Object.assign(elec, r.volver); defs.forEach(x => { if (x.clave in r.volver) delete vals[x.clave]; }); resolver(false); poner(); guardar(); pintarResumen(g); } };
        // Sección única de color para varios bandos: leyenda (quién es cada color) + una sola paleta; un color elegido por un bando no puede repetirse en otro.
        const cuerpoMulti = g => {
          const slots = g.multi; let act = 0; const cont = el('div', { class: 'ap-multi' });
          const pintar = () => {
            const usados = new Set(slots.map(x => elec[x.clave]).filter(x => x !== 'original')), sg = slots[act];
            cont.replaceChildren(
              el('div', { class: 'ap-ley', role: 'group', 'aria-label': 'Leyenda de colores' }, ...slots.map((x, i) => { const q = x.opciones.find(z => z.id === elec[x.clave]);
                return el('button', { type: 'button', class: 'ap-slot' + (i === act ? ' on' : ''), 'data-s': i }, q && q.sw ? el('i', { class: 'sw', style: `background:${q.sw[0]}` }) : el('i', { class: 'sw orig' }, '↩'), el('span', {}, g.leyenda[i])); })),
              el('small', { class: 'ap-sec' }, `Elige el color de: ${g.leyenda[act]}`),
              el('div', { class: 'seg' }, ...sg.opciones.map(o => { const b = boton(sg, o); if (o.id !== 'original' && usados.has(o.id) && elec[sg.clave] !== o.id) { b.classList.add('dis'); b.disabled = true; b.title = o.nombre + ' (ya en uso)'; } return b; })));
          };
          cont.addEventListener('click', e => {
            const sl = e.target.closest('.ap-slot'); if (sl) { act = +sl.dataset.s; pintar(); return; }
            const b = e.target.closest('.ap-o'); if (!b || b.disabled) return;
            elegir(slots[act], b.dataset.o); pintarResumen(g); if (act < slots.length - 1) act++; pintar();
          });
          pintar(); return cont;
        };
        // Varios grupos en un solo desplegable («Estilos de Fichas», «Estilos de Dados»): cada subgrupo con su rótulo.
        const cuerpoSub = g => {
          const cont = el('div', { class: 'ap-sub' });
          for (const sg of g.sub) {
            const cu = cuerpoDe(Object.assign(Object.create(sg), { sub: null })); cu.classList.add('ap-cuerpo');
            cu.addEventListener('click', e => {
              const b = e.target.closest('.ap-o, .ap-ficha'); if (!b || b.dataset.o == null) return;
              elegir(sg, b.dataset.o); cu.querySelectorAll('.ap-o,.ap-ficha').forEach(x => x.classList.toggle('on', x.dataset.o === elec[sg.clave])); pintarResumen(g);
            });
            cont.append(el('small', { class: 'ap-sec' }, sg.etiqueta || sg.titulo), cu);
          }
          return cont;
        };
        const cuerpoDe = g => {
          if (g.multi) return cuerpoMulti(g);
          if (g.sub) return cuerpoSub(g);
          const imgs = g.opciones.some(o => o.img) && g.forma;
          if (imgs) return el('div', { class: 'ap-rej ap-' + g.forma }, ...g.opciones.map(o => el('button', { type: 'button', class: 'ap-ficha' + (elec[g.clave] === o.id ? ' on' : ''), 'data-o': o.id, title: o.nombre },
            o.img ? el('img', { src: o.img, alt: '', loading: 'lazy' }) : el('span', { class: 'ap-azar' }, o.icono || (o.nada ? '🚫' : '🎲')), el('small', {}, o.nombre))));
          const out = []; let sec = null;
          for (const o of g.opciones) { if (o.sec && o.sec !== sec) { sec = o.sec; out.push(el('small', { class: 'ap-sec' }, sec)); } out.push(boton(g, o)); }
          return el('div', { class: g.opciones.some(o => o.emoji) ? 'ap-emojis' : 'seg' }, out);
        };
        const secciones = defs.filter(g => !g.oculto).map(g => {
          const det = el('details', { class: 'ap-det' }), sum = el('summary', { class: 'ap-link' }); resumenSec.set(g.clave, sum); pintarResumen(g);
          const cuerpo = cuerpoDe(g); cuerpo.classList.add('ap-cuerpo');
          if (!g.multi && !g.sub) cuerpo.addEventListener('click', e => {
            const b = e.target.closest('.ap-o, .ap-ficha'); if (!b) return;
            const idO = b.dataset.o; if (idO == null) return;
            elegir(g, idO); cuerpo.querySelectorAll('.ap-o,.ap-ficha').forEach(x => x.classList.toggle('on', x.dataset.o === elec[g.clave]));
          });
          det.append(sum, cuerpo);
          det.addEventListener('toggle', () => { if (det.open) secciones_.forEach(d => { if (d !== det) d.open = false; }); });
          return det;
        });
        const secciones_ = secciones; if (secciones.length === 1) secciones[0].open = true;
        const wrap = el('div', { class: 'ap-acordeon' }, ...secciones);
        let cerrar;
        const rest = el('button', { class: 'btn', onclick: () => { defs.forEach(g => { elec[g.clave] = g.def; delete vals[g.clave]; }); resolver(true); poner(); guardar(); refrescarVista(); if (alCambiar) alCambiar({ ...vals }); cerrar(); } }, 'Restablecer');
        const ok = el('button', { class: 'btn on', onclick: () => cerrar() }, 'Listo');
        cerrar = hoja([el('h2', {}, '🎨 Apariencia'), wrap, el('div', { class: 'bar', style: 'margin-top:14px' }, rest, ok)], typeof alCerrarV === 'function' ? alCerrarV : null);
      };
      abrirAsp = abrir;
      return { valores: vals, abrir, sortear() { resolver(true); poner(); }, elegida: c => elec[c], elegir(c, v) { elec[c] = v; delete vals[c]; resolver(false); poner(); guardar(); } };   // sortear(): nueva baraja/dorso al azar (partida nueva)
    },
    css(url) {
      const href = String(url);
      if ([...document.querySelectorAll('link[data-juego]')].some(l => l.href === href)) return Promise.resolve();
      // Las hojas de /css/ (cartas.css) son compartidas; las de cada juego solo se activan mientras ese juego está abierto.
      const comun = new URL(href).pathname.includes('/css/');
      return new Promise(res => { const l = el('link', { rel: 'stylesheet', href, 'data-juego': comun ? '*' : id }); l.onload = l.onerror = () => res(); document.head.append(l); });
    },
  };
}

/* ---------- rutas ---------- */
function ruta() {
  const rutaHash = location.hash.replace(/^#\/?/, '').split('?')[0];
  const [a, b] = rutaHash.split('/');
  if (a === 'juego' && JUEGOS.some(j => j.id === b)) return { v: 'juego', id: b, cat: JUEGOS.find(j => j.id === b).categoria };
  if (a === 'cat' && (b === 'favoritos' || Object.keys(CATEGORIAS).includes(b))) return { v: 'inicio', cat: b };
  return { v: a === 'stats' || a === 'ajustes' ? a : 'inicio', cat: null };
}
// Botón flotante 2D/3D (solo en los juegos con grupo de Apariencia «vista»): cambia de vista al instante desde cualquier punto de la pantalla.
let btnVista = null;
const quitarVista = () => { if (btnVista) { btnVista.remove(); btnVista = null; } };
const posVista = () => { const t = document.querySelector('.top'); if (btnVista && t) btnVista.style.top = Math.round(t.getBoundingClientRect().bottom + 8) + 'px'; };
window.addEventListener('resize', posVista);
async function cerrarJuego() {
  quitarVista();
  if (!actual) return;
  const a = actual; actual = null;
  try { await a.mod.unmount?.(); } catch (e) { console.error(e); }
  menuItems = [];
}
async function render() {
  const t = ++token;
  await cerrarJuego();
  const r = ruta();
  // Dentro de un juego queda marcada la pestaña de su categoría
  nav.innerHTML = RUTAS.map(([k, ic, tx, h]) => {
    const activa = k === 'cat-' + (r.cat || '') ? (r.v === 'inicio' || r.v === 'juego') : k === r.v;
    return `<a href="${h}" class="${activa ? 'on' : ''}" ${activa ? 'aria-current="page"' : ''}><span class="${ic.startsWith('img:') ? 'im' : ''}" aria-hidden="true">${ic.startsWith('img:') ? `<img src="img/marca/${ic.slice(4)}.webp" alt="" width="30" height="30">` : ic}</span><b>${tx}</b></a>`;
  }).join('');
  app.innerHTML = '';
  const enFav = r.v === 'inicio' && r.cat === 'favoritos';
  document.body.classList.toggle('fijo', r.v === 'inicio' && !enFav);
  document.body.classList.toggle('fondo', r.v === 'stats' || r.v === 'ajustes' || enFav);
  document.body.classList.toggle('jfondo', r.v === 'juego');                 // páginas de juego: mismo fondo y scroll interno
  { const tp = document.querySelector('.top'); if (tp) document.documentElement.style.setProperty('--htop', tp.offsetHeight + 'px'); }   // mismo fondo que las categorías          // inicio y categorías: pantalla fija, sin desplazamiento
  if (r.v === 'juego') return abrirJuego(r.id, t);
  if (r.v === 'inicio') { if (enFav) vFavoritos(); else { vInicio(r.cat); if (r.cat) colorearFichas(); } } else ({ stats: vStats, ajustes: vAjustes })[r.v]();
  window.scrollTo(0, 0); app.scrollTop = 0;
}
async function abrirJuego(id, t) {
  const j = JUEGOS.find(x => x.id === id);
  nombreVista = j.nombre; cabTxt(j.nombre, '#/cat/' + j.categoria);
  app.innerHTML = '<p class="note">Cargando…</p>';
  let mod;
  await cargarBarajas();                       // índice de barajas/dorsos de imagen (no falla: sin él solo salen las cartas dibujadas)
  try { mod = await j.cargar(); } catch (e) { console.error(e); if (t === token) app.innerHTML = '<div class="vacio"><img class="goli" src="img/goli/confundido.webp" alt="" width="110" height="150"><p class="msg err">No se pudo cargar el juego. Comprueba la conexión y recarga.</p></div>'; return; }
  if (t !== token) return;
  // Desactiva las hojas de estilo de otros juegos abiertos antes (evita choques de nombres de clase) y reactiva las de este.
  document.querySelectorAll('link[data-juego]').forEach(l => { l.disabled = !(l.dataset.juego === '*' || l.dataset.juego === id); });
  const root = el('div', { class: 'juego juego-' + id });
  app.innerHTML = ''; app.append(root);
  const api = crearApi(j, store.getJuego(id), mod, root);
  actual = { j, mod, api };
  window.scrollTo(0, 0);                                    // arriba al entrar (antes de montar: un montaje lento no debe devolver al jugador arriba cuando ya ha bajado)
  try { await mod.mount(root, api); } catch (e) { console.error(e); root.innerHTML = '<p class="msg err">Error al abrir el juego.</p>'; return; }
  api.ofrecerTutorial();
}
window.addEventListener('hashchange', render);
/* Deslizar a izquierda/derecha cambia de pantalla en el orden del menú superior (Lógica → … → Ajustes).
   En una partida solo cuenta si el gesto empieza en el fondo (no sobre tableros, botones, campos ni lienzos) y es claramente horizontal. */
(() => {
  let t0 = null;
  const INTERACTIVO = 'button,a,input,select,textarea,canvas,label,summary,[role=button],[tabindex],[draggable=true],.e3d,.ck,.hoja,.modal,.flotante,[class*=tab],[class*=tablero],[class*=rejilla],[class*=grid]';
  const desplazable = n => { for (; n && n !== document.body; n = n.parentElement) { const o = getComputedStyle(n).overflowX; if ((o === 'auto' || o === 'scroll') && n.scrollWidth > n.clientWidth + 2) return true; } return false; };
  document.addEventListener('touchstart', e => {
    t0 = null; if (e.touches.length !== 1 || document.querySelector('.hoja,.modal,.htmodal,.flotante')) return;
    const r = ruta(), tg = e.target; if (!(tg instanceof Element)) return;
    if (r.v === 'juego' && (tg.closest(INTERACTIVO) || desplazable(tg))) return;
    if (r.v !== 'juego' && desplazable(tg)) return;
    t0 = { x: e.touches[0].clientX, y: e.touches[0].clientY, t: Date.now(), r };
  }, { passive: true });
  document.addEventListener('touchend', e => {
    const g = t0; t0 = null; if (!g || !e.changedTouches.length) return;
    const dx = e.changedTouches[0].clientX - g.x, dy = e.changedTouches[0].clientY - g.y;
    if (Date.now() - g.t > 700 || Math.abs(dx) < 70 || Math.abs(dx) < Math.abs(dy) * 1.8) return;
    const id = g.r.v === 'juego' ? 'cat-' + g.r.cat : g.r.v === 'inicio' ? (g.r.cat ? 'cat-' + g.r.cat : null) : g.r.v;
    const i = RUTAS.findIndex(x => x[0] === id); if (i < 0) return;
    const n = RUTAS[i + (dx < 0 ? 1 : -1)]; if (n) location.hash = n[3];
  }, { passive: true });
})();
app.addEventListener('keydown', e => { const fv = e.target.closest && e.target.closest('[data-fav],[data-favg]'); if (fv && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); e.stopPropagation(); if (fv.dataset.favg) alternarFavGrupo(fv.dataset.favg); else alternarFav(fv.dataset.fav, fv); } });
app.addEventListener('click', e => { const fv = e.target.closest('[data-fav],[data-favg]'); if (fv) { e.preventDefault(); e.stopPropagation(); if (fv.dataset.favg) alternarFavGrupo(fv.dataset.favg); else alternarFav(fv.dataset.fav, fv); return; } const b = e.target.closest('[data-grupo]'); if (b) elegirJuego(b.dataset.grupo); const g = e.target.closest('[data-gen]'); if (g && actual) actual.api.gen(g.dataset.gen); });

/* ---------- inicio ---------- */
function enCursoDe(j) { const e = store.getResumen(j.id); return e && !e.fin && e.resumen ? e : null; }
function ficha(j) {
  const e = store.getResumen(j.id);
  const curso = e && !e.fin && e.resumen;
  const sub = curso ? 'Continuar · ' + esc(e.resumen) : e && e.fin && e.resumen ? esc(e.resumen) : esc(j.descripcion);
  return `<a class="ficha ${curso ? 'curso' : ''}" href="#/juego/${j.id}" style="--c:${j.color}"><span class="ico" aria-hidden="true">${emblema(j.id)}</span><b>${esc(j.nombre)}</b><small>${sub}</small>${estrella(j.id)}</a>`;
}
// Favoritos: se guardan en los ajustes (y van en la copia de seguridad)
const favs = () => (aj.ajustes().fav || []).filter(id => JUEGOS.some(j => j.id === id));
const esFav = id => favs().includes(id);
const favGrupo = gid => { const g = GRUPOS.find(x => x.id === gid); return g ? g.juegos.filter(id => JUEGOS.some(j => j.id === id)) : []; };
const grupoFav = gid => { const l = favGrupo(gid); return l.length > 0 && l.every(esFav); };
const estrellaG = gid => { const f = grupoFav(gid); return `<span class="fav ${f ? 'on' : ''}" data-favg="${gid}" role="button" tabindex="0" aria-pressed="${f}" aria-label="${f ? 'Quitar los juegos de la ficha de favoritos' : 'Añadir los juegos de la ficha a favoritos'}">${f ? '★' : '☆'}</span>`; };
function pintarFavs() {
  document.querySelectorAll('[data-fav]').forEach(n => { const f = esFav(n.dataset.fav); n.classList.toggle('on', f); n.textContent = f ? '★' : '☆'; n.setAttribute('aria-pressed', String(f)); n.setAttribute('aria-label', f ? 'Quitar de favoritos' : 'Añadir a favoritos'); });
  document.querySelectorAll('[data-favg]').forEach(n => { const f = grupoFav(n.dataset.favg); n.classList.toggle('on', f); n.textContent = f ? '★' : '☆'; n.setAttribute('aria-pressed', String(f)); n.setAttribute('aria-label', f ? 'Quitar los juegos de la ficha de favoritos' : 'Añadir los juegos de la ficha a favoritos'); });
  const nf = favs().length, c = document.getElementById('accFavN'); if (c) c.textContent = nf ? `${nf} juego${nf === 1 ? '' : 's'}` : 'Ninguno aún';
}
function alternarFavGrupo(gid) {
  const ids = favGrupo(gid), g = GRUPOS.find(x => x.id === gid); if (!g || !ids.length) return;
  const todos = ids.every(esFav), l = favs(), nueva = todos ? l.filter(x => !ids.includes(x)) : [...l, ...ids.filter(x => !l.includes(x))];
  aj.set('fav', nueva); pintarFavs();
  const nombres = ids.map(id => JUEGOS.find(j => j.id === id).nombre).join(' y ');
  aviso(todos ? `☆ ${nombres}: ya no son favoritos` : `★ ${nombres} añadidos a favoritos`, 1800);
  if (ruta().cat === 'favoritos' && todos) vFavoritos();
}
const estrella = id => { const f = esFav(id); return `<span class="fav ${f ? 'on' : ''}" data-fav="${id}" role="button" tabindex="0" aria-pressed="${f}" aria-label="${f ? 'Quitar de favoritos' : 'Añadir a favoritos'}">${f ? '★' : '☆'}</span>`; };
function alternarFav(id, nodo) {
  const j = JUEGOS.find(x => x.id === id); if (!j) return;
  const l = favs(), ya = l.includes(id), nueva = ya ? l.filter(x => x !== id) : [...l, id];
  aj.set('fav', nueva); 
  pintarFavs();
  aviso(ya ? `☆ ${j.nombre} ya no es favorito` : `★ ${j.nombre} añadido a favoritos`, 1600);
  if (ruta().cat === 'favoritos' && ya) vFavoritos();
}
function vFavoritos() {
  nombreVista = 'Favoritos'; cabTxt('JugamiGO');
  const js = favs().map(id => JUEGOS.find(j => j.id === id));
  app.innerHTML = `<section class="panel"><h3>${imgIc('favorito')} Mis favoritos</h3>${js.length ? '<p class="note">Tus juegos preferidos, a un toque. Pulsa la ★ de un juego para quitarlo.</p>' : '<div class="vacio"><img src="img/marca/vacio-partidas.webp" alt="" width="190" height="200"><p class="note">Aún no tienes favoritos. Toca la ☆ de cualquier juego (o de un resultado de la búsqueda) para guardarlo aquí.</p></div>'}</section>`
    + (js.length ? `<div class="rejilla fav-rej">${js.map(ficha).join('')}</div>` : '') + `<div class="bar" style="margin-top:14px"><a class="btn on" href="#/">‹ Volver al inicio</a></div>`;
  colorearFichas();
}
// Atajos del inicio: continuar la última partida, reto del día y juego al azar
function ultimoEnCurso() { let b = null, bt = 0; for (const j of JUEGOS) { const e = store.getResumen(j.id); if (e && !e.fin && e.resumen && (e.t || 0) >= bt) { b = j; bt = e.t || 0; } } return b; }
function retoDeHoy() {
  const lista = JUEGOS.filter(j => /reto del d[ií]a/i.test(j.descripcion)); if (!lista.length) return null;
  const f = hoy(); let h = 0; for (const c of f) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  const j = lista[h % lista.length]; return { j, hecho: logros.retoHecho(f, j.id) };
}
const norm = t => String(t).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
function resultadosBusqueda(q) {
  const ps = norm(q).split(/\s+/).filter(Boolean); if (!ps.length) return '';
  const r = JUEGOS.filter(j => { const t = norm(`${j.nombre} ${j.descripcion} ${CATEGORIAS[j.categoria]}`); return ps.every(p => t.includes(p)); });
  if (!r.length) return `<div class="vacio"><img class="goli" src="img/goli/buscando.webp" alt="" width="110" height="150"><p class="note">Ningún juego coincide con «${esc(q)}».</p></div>`;
  return r.map(j => `<a class="res" href="#/juego/${j.id}" style="--c:${j.color}"><span class="res-i" aria-hidden="true">${emblema(j.id, 34)}</span><span class="res-t"><b>${esc(j.nombre)}</b><small>${esc(CATEGORIAS[j.categoria])} · ${esc(j.descripcion)}</small></span>${estrella(j.id)}</a>`).join('');
}
// Ficha de un grupo de juegos: al pulsarla se abre la ventana para elegir uno
function fichaGrupo(g, js) {
  const cur = js.filter(enCursoDe), sub = cur.length ? 'Continuar · ' + esc(cur.map(j => j.nombre).join(' · ')) : esc(js.map(j => j.nombre).join(' · '));
  return `<button type="button" class="ficha ${cur.length ? 'curso' : ''}" data-grupo="${g.id}" style="--c:${g.color}" aria-haspopup="dialog"><span class="ico" aria-hidden="true">${emblema(g.juegos[0])}</span><b>${esc(g.nombre)}</b><small>${sub}</small>${estrellaG(g.id)}</button>`;
}
function elegirJuego(gid) {
  const g = GRUPOS.find(x => x.id === gid); if (!g) return;
  const js = g.juegos.map(id => JUEGOS.find(x => x.id === id));
  const opciones = js.map(j => { const e = store.getResumen(j.id), cur = e && !e.fin && e.resumen;
    return `<a class="eleg" href="#/juego/${j.id}" data-cerrar style="--c:${j.color}"><span class="ico" aria-hidden="true">${emblema(j.id, 44)}</span><span class="eleg-t"><b>${esc(j.nombre)}</b><small>${cur ? 'Continuar · ' + esc(e.resumen) : esc(j.descripcion)}</small></span>${estrella(j.id)}<i aria-hidden="true">›</i></a>`; }).join('');
  const cerrar = hoja([el('h2', {}, `${g.icono} ${g.nombre}`), el('p', { class: 'note' }, '¿A qué quieres jugar?'), (() => { const d = el('div', { class: 'elegir' }); d.innerHTML = opciones; d.addEventListener('click', e => { const fv = e.target.closest('[data-fav]'); if (fv) { e.preventDefault(); e.stopPropagation(); alternarFav(fv.dataset.fav, fv); return; } if (e.target.closest('[data-cerrar]')) cerrar(); }); d.addEventListener('keydown', e => { const fv = e.target.closest('[data-fav]'); if (fv && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); e.stopPropagation(); alternarFav(fv.dataset.fav, fv); } }); return d; })(),
    el('div', { class: 'bar', style: 'margin-top:12px' }, el('button', { class: 'btn', onclick: () => cerrar() }, 'Cancelar'))]);
  const h = [...document.querySelectorAll('.modal > .hoja')].pop(); if (h) h.classList.add('hoja-elegir');
}
// Inicio por categorías plegables: solo se abre una a la vez y se recuerda la última abierta.
const COLOR_CAT = { logica: '#6D5FD9', tablero: '#E4572E', cartas: '#1B998B', palabras: '#F2B134', arcade: '#2F7BD9' };
const ICONO_CAT = { logica: '🧠', tablero: '🎲', cartas: '🃏', palabras: '🔤', arcade: '🕹️' };
function vInicio(filtro = null) {
  avisoCopia();
  const nombreFiltro = filtro ? CATEGORIAS[filtro] : null;
  nombreVista = nombreFiltro || 'JugamiGO'; cabTxt('JugamiGO');
  const cats = Object.entries(CATEGORIAS).filter(([k]) => JUEGOS.some(j => j.categoria === k) && (!filtro || filtro === k));
  if (!filtro) {                                                    // Pantalla de inicio: el logo de fondo y las categorías a todo el alto (sin desplazamiento)
    const cont = ultimoEnCurso(), reto = retoDeHoy(), nf = favs().length;
    const acc = (href, ico, tit, sub, extra = '') => `<${href ? `a href="${href}"` : 'button type="button"'} class="acc" ${extra}><span class="acc-i" aria-hidden="true">${ico}</span><b>${tit}</b><small>${sub}</small></${href ? 'a' : 'button'}>`;
    const top = `<div class="ini-top"><label class="ini-bus"><span aria-hidden="true">${imgIc('buscar')}</span><input type="search" id="iniBus" placeholder="Buscar un juego…" autocomplete="off" enterkeyhint="search" aria-label="Buscar un juego"></label>
      <div class="ini-acc">${cont ? acc('#/juego/' + cont.id, imgIc('continuar', 26), 'Continuar', esc(cont.nombre)) : acc('', '<img class="ic" src="img/medallas/primera.webp" alt="" width="26" height="29" style="width:auto;height:26px">', 'Al azar', 'Sorpréndeme', 'id="accAzar"')}${reto ? acc('#/juego/' + reto.j.id, imgIc('retos', 26), 'Reto de hoy', esc(reto.j.nombre) + (reto.hecho ? ' ✓' : '')) : ''}${acc('#/cat/favoritos', '⭐', 'Favoritos', `<span id="accFavN">${nf ? nf + (nf === 1 ? ' juego' : ' juegos') : 'Ninguno aún'}</span>`)}</div>
      <div class="ini-res" id="iniRes" hidden aria-live="polite"></div></div>`;
    app.innerHTML = `<div class="ini" role="navigation" aria-label="Categorías de juegos">${top}${cats.map(([k, n]) => {
      const js = JUEGOS.filter(j => j.categoria === k), enCurso = js.filter(j => { const e = store.getResumen(j.id); return e && !e.fin && e.resumen; }).length;
      return `<a class="ini-cat" href="#/cat/${k}" style="--c:${COLOR_CAT[k] || '#6B4DE0'}"><span class="ini-ico" aria-hidden="true"><img src="img/marca/ruta-${k}.webp" alt="" width="84" height="84"></span><span class="ini-t"><b>Juegos de ${esc(n)}</b><small>${js.length} juegos${enCurso ? ` · ${enCurso} en curso` : ''}</small></span><span class="ini-fl" aria-hidden="true">›</span></a>`;
    }).join('')}</div>`;
    const bus = $('#iniBus'), res = $('#iniRes'), ini = app.querySelector('.ini');
    bus.addEventListener('input', () => { const q = bus.value.trim(); res.hidden = !q; ini.classList.toggle('buscando', !!q); res.innerHTML = q ? resultadosBusqueda(q) : ''; });
    const azar = $('#accAzar'); if (azar) azar.addEventListener('click', () => { location.hash = '#/juego/' + JUEGOS[Math.floor(Math.random() * JUEGOS.length)].id; });
    return;
  }
  const grupos = cats.map(([k, n]) => {
    const es = entradas(k), js = JUEGOS.filter(j => j.categoria === k);
    const enCurso = js.filter(j => { const e = store.getResumen(j.id); return e && !e.fin && e.resumen; }).length;
    return `<section class="cat-seccion" data-cat="${k}">
      <h2 class="cat"><span class="cico" aria-hidden="true"><img src="img/marca/ruta-${k}.webp" alt="" width="44" height="44"></span><span class="cnom">${esc(n)}</span>${enCurso ? `<span class="cact" title="Partidas en curso">${enCurso} en curso</span>` : ''}</h2>
      <div class="rejilla">${es.map(x => x.tipo === 'grupo' ? fichaGrupo(x.g, x.js) : ficha(x.j)).join('')}</div></section>`;
  }).join('');
  app.innerHTML = grupos + '';
}

/* ---------- estadísticas ---------- */
/* Las fichas de juegos (categorías y Estadísticas) toman al azar uno de estos colores del pasaporte cada vez que se pinta la pantalla.
   Se reparten en tandas barajadas, así que en cada pantalla se repiten lo menos posible y nunca salen otros colores. */
const COLORES_FICHA = ['#C9441C' /* coral */, '#137A6F' /* mar */, '#5B4FCF' /* ultramar */, '#2563C9' /* cielo */, '#14213D' /* tinta */, '#9A3412' /* sello */];
const COLORES_STATS = [...COLORES_FICHA, '#7A3E9D' /* ciruela */, '#0F766E' /* pino */, '#A16207' /* ocre */, '#B91C1C' /* carmín */];
function colorearFichas(sel = '.ficha', paleta = COLORES_FICHA) {
  let cola = [];
  app.querySelectorAll(sel).forEach(f => {
    if (!cola.length) { cola = [...paleta]; for (let i = cola.length - 1; i > 0; i--) { const k = Math.floor(Math.random() * (i + 1)); [cola[i], cola[k]] = [cola[k], cola[i]]; } }
    f.style.setProperty('--c', cola.pop());
  });
}
function vStats(catSel = null) { const y = leerScroll(); vStats_(catSel); if (ruta().v === 'stats') ponerScroll(y); }
function vStats_(catSel = null) {
  nombreVista = 'Diario de viaje'; cabTxt('JugamiGO');
  const T = stats.todas();
  revisarLogros();
  const G = logros.conseguidos(), defs = logros.definiciones(CAT_IDS), nG = defs.filter(d => G[d.id]).length;
  const R = logros.todosRetos(), diasR = Object.values(R).filter(l => Array.isArray(l) && l.length).length, totR = Object.values(R).reduce((a, l) => a + (Array.isArray(l) ? l.length : 0), 0);
  const retosHoy = (R[hoy()] || []).map(id => JUEGOS.find(j => j.id === id)).filter(Boolean);
  const sellado = j => { const x = T[j.id]; return !!(x && x.partidas); };
  const nSell = JUEGOS.filter(sellado).length, totPart = Object.values(T).reduce((a, x) => a + (x && x.partidas || 0), 0), totVic = Object.values(T).reduce((a, x) => a + (x && x.victorias || 0), 0);
  const mejorR = Object.values(T).reduce((a, x) => Math.max(a, x && x.mejorRacha || 0), 0);
  const rutas = Object.entries(CATEGORIAS).filter(([k]) => JUEGOS.some(j => j.categoria === k)).map(([k, n]) => { const js = JUEGOS.filter(j => j.categoria === k), c = js.filter(sellado).length; return `<div class="pas-ruta"><img src="img/marca/ruta-${k}.webp" alt="" width="40" height="40"><span><b>${esc(n)}</b><small>${c} de ${js.length}</small></span><i class="pas-bar"><u style="width:${Math.round(100 * c / js.length)}%"></u></i></div>`; }).join('');
  const panelPasaporte = `<section class="panel pasaporte" aria-label="Tu pasaporte"><div class="pas-cab"><img src="img/marca/portada.webp" alt="" width="76" height="102"><div><h3>Tu pasaporte</h3><p class="pas-n"><b>${nSell}</b> de ${JUEGOS.length} destinos sellados</p><i class="pas-bar grande"><u style="width:${Math.round(100 * nSell / Math.max(1, JUEGOS.length))}%"></u></i></div></div>
    <div class="pas-num"><div><b>${totPart.toLocaleString('es-ES')}</b><small>partidas</small></div><div><b>${totVic.toLocaleString('es-ES')}</b><small>victorias</small></div><div><b>${mejorR}</b><small>mejor racha</small></div></div>
    <div class="pas-rutas">${rutas}</div><div class="bar"><button class="btn" id="pasComp" type="button">${imgIc('compartir')} Compartir mi pasaporte</button></div></section>`;
  const panelLogros = `<details class="panel plog"><summary><h3>🏅 Logros · ${nG}/${defs.length}</h3><span class="plogi">${defs.filter(d => G[d.id]).map(d => `<img class="lg-mini" src="img/medallas/${d.id}.webp" alt="${esc(d.nombre)}" width="26" height="29" loading="lazy">`).join('') || `<small>Toca para ver los ${defs.length} logros</small>`}</span></summary><div class="logros">${defs.map(d => { const pg = G[d.id] ? null : logros.progreso(d.id, T, CAT_IDS), pa = pg ? Math.min(pg[0], pg[1]) : 0; return `<div class="logro ${G[d.id] ? 'on' : ''}" title="${esc(d.desc)}"><span><img src="img/medallas/${d.id}.webp" alt="" width="44" height="50" loading="lazy"></span><b>${esc(d.nombre)}</b><small>${esc(d.desc)}</small>${pg && pg[1] > 0 ? `<i class="lg-prog" role="img" aria-label="Progreso: ${pa.toLocaleString('es-ES')} de ${pg[1].toLocaleString('es-ES')}"><u style="width:${Math.round(100 * pa / pg[1])}%"></u></i><em>${pa.toLocaleString('es-ES')} / ${pg[1].toLocaleString('es-ES')}</em>` : ''}</div>`; }).join('')}</div></details>
    <div class="panel"><h3>${imgIc('retos')} Retos del día</h3><p class="note">${totR ? `Has completado ${totR} reto${totR === 1 ? '' : 's'} en ${diasR} día${diasR === 1 ? '' : 's'}.` : 'Sudoku, Nonogram, Bombardeo, Calcudoku, CruciSumas, Encajados, Sopa de letras, Crucigramas, Puentes Hashi y Números y Letras tienen un «Reto del día»: el mismo tablero para todo el mundo.'}${retosHoy.length ? ` Hoy: ${retosHoy.map(j => j.icono + ' ' + esc(j.nombre)).join(', ')}.` : ''}</p></div>`;
  const cats = Object.entries(CATEGORIAS).filter(([k]) => JUEGOS.some(j => j.categoria === k));
  const solicitada = catSel || new URLSearchParams(location.hash.split('?')[1] || '').get('categoria');
  const elegida = cats.some(([k]) => k === solicitada) ? solicitada : cats[0]?.[0];
  const tabs = `<div class="stats-tabs" role="tablist" aria-label="Categorías de estadísticas">${cats.map(([k, n]) => `<button type="button" role="tab" class="stats-tab ${k === elegida ? 'on' : ''}" aria-selected="${k === elegida}" data-stat-cat="${k}"><img src="img/marca/ruta-${k}.webp" alt="" width="30" height="30"><span>${n}</span></button>`).join('')}</div>`;
  // Fichas pequeñas de los juegos de la categoría; al pulsar una se abre su estadística en una ventana
  const tabla = j => {
    const s = T[j.id];
    if (!s || !s.partidas) return '<p class="note">Todavía sin partidas terminadas.</p>';
    const tiempos = Object.entries(s.tiempos || {}).map(([k, v]) => `<tr><td>Mejor tiempo · ${esc(k)}</td><td>${fmtTiempo(v)}</td></tr>`).join('')
      + Object.entries(s.records || {}).map(([k, v]) => `<tr><td>🏆 Récord · ${esc(k)}</td><td>${v.toLocaleString('es-ES')}</td></tr>`).join('');
    return `<table class="tabla">
      <tr><td>Partidas</td><td>${s.partidas}</td></tr>
      ${s.victorias || s.derrotas || s.tablas ? `<tr><td>Victorias · derrotas · tablas</td><td>${s.victorias} · ${s.derrotas} · ${s.tablas}</td></tr><tr><td>Racha actual · mejor racha</td><td>${s.racha} · ${s.mejorRacha}</td></tr>` : ''}
      ${tiempos}</table>`;
  };
  const fcorta = t => t ? new Date(t).toLocaleDateString('es-ES', { day: 'numeric', month: 'short' }) : '';
  const cards = JUEGOS.filter(j => j.categoria === elegida).map((j, i) => {
    const s = T[j.id], n = s && s.partidas ? s.partidas : 0, rot = ((i * 37) % 15) - 7;
    return `<button type="button" class="st-cas ${n ? 'sellada' : ''}" data-stat-juego="${j.id}" style="--rot:${rot}deg" aria-haspopup="dialog" aria-label="${esc(j.nombre)}: ${n ? 'sellado, ' + n + (n === 1 ? ' partida' : ' partidas') : 'sin sellar'}"><span class="st-sl"><span class="st-rot"><img src="img/marca/sello.webp" alt="" width="64" height="64"><img class="st-em" src="img/sellos/${j.id}.webp" alt="" width="34" height="34" loading="lazy"></span>${n ? '<i aria-hidden="true">✓</i>' : ''}</span><b>${esc(j.nombre)}</b><small>${n ? n + (n === 1 ? ' partida' : ' partidas') : 'Sin sellar'}</small>${n && s.ultima ? `<small class="st-f">${fcorta(s.ultima)}</small>` : ''}</button>`;
  }).join('');
  const D = stats.dias(), cl = stats.diaClave(), rd = stats.rachaDias(), pHoy = D[cl] || 0;
  const reto = retoDeHoy(), cont = ultimoEnCurso();
  const barras = (() => {                                            // últimas 2 semanas
    const dd = []; const d = new Date(); d.setDate(d.getDate() - 13);
    for (let i = 0; i < 14; i++) { dd.push([stats.diaClave(d), new Date(d)]); d.setDate(d.getDate() + 1); }
    const mx = Math.max(1, ...dd.map(([k]) => D[k] || 0)), W = 14 * 22;
    return `<svg class="gr-dias" viewBox="0 0 ${W} 74" role="img" aria-label="Partidas de los últimos 14 días: ${dd.reduce((a, [k]) => a + (D[k] || 0), 0)}">${dd.map(([k, f], i) => { const v = D[k] || 0, h = v ? Math.max(4, Math.round(52 * v / mx)) : 2; return `<g><rect x="${i * 22 + 3}" y="${58 - h}" width="16" height="${h}" rx="3" class="${v ? 'on' : ''}${k === cl ? ' hoy' : ''}"><title>${f.toLocaleDateString('es-ES', { day: 'numeric', month: 'short' })}: ${v}</title></rect><text x="${i * 22 + 11}" y="71" text-anchor="middle">${['D', 'L', 'M', 'X', 'J', 'V', 'S'][f.getDay()]}</text></g>`; }).join('')}</svg>`;
  })();
  const top = Object.entries(T).filter(([, x]) => x && x.partidas).sort((a, b) => b[1].partidas - a[1].partidas).slice(0, 5).map(([id, x]) => ({ j: JUEGOS.find(j => j.id === id), x })).filter(o => o.j);
  const mxT = Math.max(1, ...top.map(o => o.x.partidas));
  const barTop = top.length ? `<div class="gr-top"><h4>Tus juegos más jugados</h4>${top.map(({ j, x }) => `<div class="gr-fila"><span class="gr-n">${j.icono} ${esc(j.nombre)}</span><i class="gr-b"><u style="width:${Math.round(100 * x.partidas / mxT)}%"></u></i><b>${x.partidas}</b></div>`).join('')}</div>` : '';
  const panelHoy = `<section class="panel hoyp" aria-label="Hoy"><h3>Hoy</h3>
    <div class="pas-num"><div><b>${rd}</b><small>${rd === 1 ? 'día seguido' : 'días seguidos'}</small></div><div><b>${pHoy}</b><small>${pHoy === 1 ? 'partida hoy' : 'partidas hoy'}</small></div><div><b>${Object.keys(D).length}</b><small>días jugados</small></div></div>
    ${totPart ? barras : ''}${barTop}
    <div class="ini-acc hoy-acc">${reto ? `<a class="acc" href="#/juego/${reto.j.id}"><span class="acc-i" aria-hidden="true">${imgIc('retos', 26)}</span><b>Reto del día${reto.hecho ? ' · hecho' : ''}</b><small>${esc(reto.j.nombre)}</small></a>` : ''}${cont ? `<a class="acc" href="#/juego/${cont.id}"><span class="acc-i" aria-hidden="true">${imgIc('continuar', 26)}</span><b>Continuar</b><small>${esc(cont.nombre)}</small></a>` : ''}</div></section>`;
  app.innerHTML = panelHoy + panelPasaporte + (nSell ? '' : '<div class="vacio"><img class="goli" src="img/goli/sellando.webp" alt="" width="130" height="140"><p class="note">Tu pasaporte está en blanco. Termina una partida de cualquier juego y se sellará aquí.</p></div>') + panelLogros + '<div class="sep-ruta" role="presentation"></div>' + tabs + `<div class="stats-fichas stats-sellos">${cards || '<p class="note">No hay juegos en esta categoría.</p>'}</div><div class="bar stats-reset-actions"><button class="btn danger" id="stResetCat">Reiniciar estadísticas de ${esc(elegida ? CATEGORIAS[elegida] : 'esta categoría')}</button><button class="btn danger" id="stResetAll">Reiniciar todo el diario</button></div><p class="note">Los 🏅 logros ya conseguidos no se pierden al reiniciar el diario.</p>`;
  $('#pasComp').addEventListener('click', async () => {
    try { const m = await import('./core/imagen.js'); await m.compartirImagen({ titulo: 'Mi pasaporte JugamiGO', linea: `${nSell} de ${JUEGOS.length} destinos sellados`, pie: `${totVic.toLocaleString('es-ES')} victorias · mejor racha ${mejorR}`, texto: `Llevo ${nSell} de ${JUEGOS.length} destinos sellados en JugamiGO` }, aviso); }
    catch (e) { console.error(e); aviso('No se pudo crear la imagen'); }
  });
  app.querySelectorAll('[data-stat-cat]').forEach(b => b.addEventListener('click', () => {
    history.replaceState(null, '', '#/stats?categoria=' + b.dataset.statCat);      // sin cambiar de pantalla: no salta el scroll
    const y = leerScroll(); vStats(b.dataset.statCat); ponerScroll(y);
  }));
  app.querySelectorAll('[data-stat-juego]').forEach(b => b.addEventListener('click', () => {
    const j = JUEGOS.find(x => x.id === b.dataset.statJuego); if (!j) return;
    const cerrar = hoja([el('h2', {}, `${j.icono} ${j.nombre}`), (() => { const d = el('div', { class: 'cuerpo' }); d.innerHTML = tabla(j); return d; })(), el('div', { class: 'bar', style: 'margin-top:12px' }, el('button', { class: 'btn on', onclick: () => cerrar() }, 'Cerrar'))]);
    const h = [...document.querySelectorAll('.modal > .hoja')].pop(); if (h) h.classList.add('hoja-img');
  }));
  $('#stResetCat').addEventListener('click', () => {
    const nombre = CATEGORIAS[elegida] || 'esta categoría';
    if (!confirm(`¿Borrar únicamente las estadísticas de ${nombre}? Las demás categorías se conservarán.`)) return;
    const idsCategoria = new Set(JUEGOS.filter(j => j.categoria === elegida).map(j => j.id));
    const restantes = Object.fromEntries(Object.entries(stats.todas()).filter(([id]) => !idsCategoria.has(id)));
    stats.importar(restantes);
    vStats();
  });
  $('#stResetAll').addEventListener('click', () => {
    if (confirm('¿Borrar todas las estadísticas de todas las categorías? Esta acción no se puede deshacer.')) { stats.reiniciar(); vStats(); }
  });
}

/* ---------- ajustes y copia de seguridad ---------- */
let msgAj = { t: '', err: false };
// Ajustes → «Sin conexión»: cuántos juegos están guardados en el móvil para jugar sin internet.
async function estadoSinConexion() {
  const el = $('#gOff'), bar = $('#gOffBar'); if (!el) return;
  if (!('serviceWorker' in navigator) || !('caches' in window)) { el.textContent = '⚠️ Este navegador no permite jugar sin conexión.'; return; }
  try {
    const reg = await navigator.serviceWorker.getRegistration();
    const listos = (await Promise.all(JUEGOS.map(j => caches.match(new URL(`js/games/${j.id}/index.js`, location.href).href)))).filter(Boolean).length;
    if (!$('#gOff')) return;
    const activo = !!(reg && reg.active);
    if (activo && listos === JUEGOS.length) { el.textContent = `✅ Lista para jugar sin conexión: los ${JUEGOS.length} juegos están guardados en este dispositivo.`; bar.hidden = true; }
    else if (activo && listos) { el.textContent = `⚠️ Solo ${listos} de ${JUEGOS.length} juegos están guardados. Con internet, pulsa «Volver a intentarlo».`; bar.hidden = false; }
    else { el.textContent = reg && (reg.installing || reg.waiting) ? '⏳ Guardando los juegos para usarlos sin conexión… espera unos segundos.' : '⚠️ El modo sin conexión aún no está listo. Abre la app con internet y pulsa «Volver a intentarlo».'; bar.hidden = false; if (reg && (reg.installing || reg.waiting)) setTimeout(estadoSinConexion, 3000); }
  } catch { el.textContent = '⚠️ No se pudo comprobar el modo sin conexión.'; }
}
// «Descargar todo»: el service worker baja imágenes, barajas y diccionario y avisa del avance con mensajes.
const swEnviar = async m => { try { const r = await navigator.serviceWorker.getRegistration(); if (r && r.active) r.active.postMessage(m); } catch { /* sin service worker */ } };
function pintarDescarga(m) {
  const des = $('#gDes'), prog = $('#gProg'), bd = $('#gDesc'), bc = $('#gCanc'), bq = $('#gQuit'); if (!des) return;
  if (m.tipo === 'descarga') {
    prog.hidden = false; prog.firstElementChild.style.width = Math.round(100 * m.hecho / m.total) + '%';
    des.textContent = `Descargando… ${m.hecho} de ${m.total}${m.fallos ? ` (${m.fallos} sin descargar)` : ''}. Puedes seguir jugando.`; bd.hidden = true; bc.hidden = false; bq.hidden = true; return;
  }
  if (m.tipo === 'descarga-fin') { prog.hidden = true; bc.hidden = true; return; }
  if (m.tipo !== 'estado-descarga') return;
  prog.hidden = !m.descargando; bc.hidden = !m.descargando;
  if (m.descargando) { des.textContent = 'Descargando…'; bd.hidden = true; bq.hidden = true; return; }
  const falta = m.total - m.guardados;
  if (!falta) { des.textContent = '✅ Todo descargado: imágenes, barajas y diccionario. Ya puedes jugar en Modo Avión.'; bd.hidden = true; bq.hidden = false; }
  else { des.textContent = `Imágenes, barajas y diccionario: ${m.guardados} de ${m.total} guardados. «Descargar todo» baja el resto (unos ${m.mb} MB; mejor con Wi-Fi) para jugar sin conexión con todo su dibujo.`; bd.hidden = !navigator.onLine; bd.textContent = m.guardados ? '⬇️ Terminar la descarga' : '⬇️ Descargar todo'; bq.hidden = !m.guardados; }
}
if ('serviceWorker' in navigator) navigator.serviceWorker.addEventListener('message', e => { if (e.data && e.data.tipo) pintarDescarga(e.data); });
function vAjustes() { const y = leerScroll(); vAjustes_(); if (ruta().v === 'ajustes') ponerScroll(y); }   // al volver a pintar (cambiar un ajuste…) no se salta arriba
function vAjustes_() {
  nombreVista = 'Ajustes'; cabTxt('JugamiGO');
  const A = aj.ajustes();
  const seg = (k, opts) => `<div class="seg">${opts.map(([v, l]) => `<button class="btn ${A[k] === v ? 'on' : ''}" data-set="${k}" data-v="${v}">${l}</button>`).join('')}</div>`;
  const TT = stats.todas(), nSell = JUEGOS.filter(j => TT[j.id] && TT[j.id].partidas).length;
  app.innerHTML = `
  <section class="panel ajcab"><img src="img/marca/portada.webp" alt="" width="64" height="86"><div><h3>Pasaporte del viajero</h3><p class="note">${nSell} de ${JUEGOS.length} destinos sellados · JugamiGO ${VERSION}</p></div></section>
  <div class="panel"><h3>${imgIc('apariencia')} Apariencia</h3><div class="fila"><span>Tema</span>${seg('tema', [['auto', 'Auto'], ['claro', 'Papel'], ['oscuro', 'Noche']])}</div><p class="note">Papel: crema y tinta, para el día. Noche: cuero azul y oro, para la oscuridad. «Auto» sigue el modo de tu móvil.</p></div>
  <div class="panel"><h3>${imgIc('sonido')} Sonido y vibración</h3>
    <div class="fila"><span>Sonidos</span>${seg('sonido', [[true, 'Sí'], [false, 'No']])}</div>
    <div class="fila"><span>Vibración</span>${seg('vibracion', [[true, 'Sí'], [false, 'No']])}</div></div>
  <div class="panel"><h3>${imgIc('celebracion')} Victorias</h3>
    <div class="fila"><span>Celebrar al ganar</span>${seg('celebrar', [[true, 'Sí'], [false, 'No']])}</div></div>
  <div class="panel"><h3>${imgIc('accesibilidad')} Accesibilidad</h3>
    <div class="fila fila-col"><span>Tamaño del texto</span>${seg('texto', [['normal', 'Normal'], ['grande', 'Grande'], ['enorme', 'Enorme']])}</div>
    <div class="fila"><span>Contraste</span>${seg('contraste', [['normal', 'Normal'], ['alto', 'Alto']])}</div>
    <div class="fila"><span>Animaciones</span>${seg('anim', [[true, 'Sí'], [false, 'No']])}</div>
    <p class="note">El texto grande afecta a paneles, listas y ayudas. «Animaciones: No» quita los movimientos y la bienvenida.</p></div>
  <div class="panel"><h3>${imgIc('copia')} Copia de seguridad</h3>
    <p class="note">Tus partidas y estadísticas se guardan solo en este navegador. Exporta un archivo .json para pasarlas a otro dispositivo o como copia.</p>
    <p class="note">${(() => { const c = copiaAntigua(); return c.u ? `Última copia: ${new Date(c.u).toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' })}${c.toca ? ' (conviene hacer otra).' : '.'}` : (c.n >= 10 ? 'Todavía no has exportado ninguna copia.' : ''); })()}</p>
    <div class="bar"><button class="btn on" id="gExp">Exportar .json</button>
      <label class="btn file">Importar .json<input type="file" id="gImp" accept=".json,application/json"></label>
      <button class="btn danger" id="gBor">Borrar partidas</button></div>
    <div class="msg ${msgAj.err ? 'err' : 'win'}" role="status">${esc(msgAj.t)}</div></div>
  <div class="sep-ruta" role="presentation"></div><div class="panel"><h3>${imgIc('avion')} Modo avión</h3><div class="vacio"><img src="img/marca/vacio-sin-conexion.webp" alt="" width="170" height="155" loading="lazy"></div><p class="note" id="gOff" role="status">Comprobando…</p>
    <div class="prog" id="gProg" hidden><i></i></div><p class="note" id="gDes" role="status"></p>
    <div class="bar"><button class="btn on" id="gDesc" hidden>⬇️ Descargar todo</button><button class="btn" id="gCanc" hidden>Cancelar</button><button class="btn" id="gQuit" hidden>Quitar descarga</button></div>
    <div class="bar" id="gOffBar" hidden><button class="btn" id="gOffRe">🔄 Volver a intentarlo</button></div></div>
  <div class="panel"><h3>Acerca de</h3><p class="note">JugamiGO · ${JUEGOS.length} juegos${enApp() ? '. ✅ Instalada en este dispositivo.' : '.'}</p>
    ${enApp() ? '' : promptInstalar ? '<div class="bar"><button class="btn on" id="gInst" type="button">📲 Instalar la app</button></div>' : `<p class="note">${esIOS() ? 'Para instalarla: pulsa Compartir ⬆️ y «Añadir a pantalla de inicio».' : 'Puedes instalarla desde el menú del navegador («Instalar app» o «Añadir a pantalla de inicio»).'}</p>`}
    <p class="note">Créditos: los dibujos de las caras de «¿Qué Cara Tienes?» están basados en <b>Vue Color Avatar</b>, de LeoKu (licencia MIT).</p></div>
  <p class="version">JugamiGO · versión ${VERSION} · by ChifoRedEs</p>`;
  app.querySelectorAll('[data-set]').forEach(b => b.addEventListener('click', () => {
    const v = b.dataset.v; aj.set(b.dataset.set, v === 'true' ? true : v === 'false' ? false : v); const y = leerScroll(); vAjustes(); ponerScroll(y);
  }));
  const bi = $('#gInst'); if (bi) bi.addEventListener('click', instalar);
  estadoSinConexion(); swEnviar({ tipo: 'estado-descarga' });
  $('#gDesc').addEventListener('click', () => { $('#gDesc').hidden = true; $('#gDes').textContent = 'Empezando la descarga…'; swEnviar({ tipo: 'descargar-todo' }); });
  $('#gCanc').addEventListener('click', () => { swEnviar({ tipo: 'cancelar-descarga' }); $('#gDes').textContent = 'Cancelando…'; });
  $('#gQuit').addEventListener('click', () => { $('#gQuit').hidden = true; swEnviar({ tipo: 'borrar-descarga' }); });
  $('#gOffRe').addEventListener('click', async () => {
    $('#gOff').textContent = 'Descargando los juegos… deja la app abierta unos segundos.';
    try { const r = await navigator.serviceWorker.getRegistration(); if (r) await r.update(); else await navigator.serviceWorker.register('./sw.js', { updateViaCache: 'none' }); } catch { /* sin red */ }
    setTimeout(estadoSinConexion, 4000);
  });
  $('#gExp').addEventListener('click', exportar);
  $('#gBor').addEventListener('click', () => {
    if (!confirm('¿Borrar todas las partidas guardadas en este navegador? (Las estadísticas se conservan.)')) return;
    JUEGOS.forEach(j => store.borrarJuego(j.id)); msgAj = { t: 'Partidas borradas.', err: false }; vAjustes();
  });
  $('#gImp').addEventListener('change', e => {
    const f = e.target.files[0]; if (!f) return;
    const rd = new FileReader();
    rd.onload = async () => {
      try { const got = await importar(JSON.parse(rd.result)); msgAj = { t: got.length ? `Importado: ${got.join(', ')}.` : 'Copia importada (sin partidas guardadas).', err: false }; }
      catch (err) { msgAj = { t: err instanceof SyntaxError ? 'El archivo no es un JSON válido.' : err.message, err: true }; }
      vAjustes();
    };
    rd.onerror = () => { msgAj = { t: 'No se pudo leer el archivo.', err: true }; vAjustes(); };
    rd.readAsText(f);
  });
}
// Aviso suave de copia de seguridad: ≥10 partidas y ≥14 días sin copia (o nunca), como mucho una vez por sesión
function copiaAntigua() {
  const T = stats.todas(), n = Object.values(T).reduce((a, x) => a + (x && x.partidas || 0), 0);
  const u = +store.leer('ultcopia', 0) || 0, d = u ? Math.floor((Date.now() - u) / 864e5) : null;
  return { n, u, d, toca: n >= 10 && (d == null || d >= 14) };
}
let copiaAvisada = false;
function avisoCopia() {
  if (copiaAvisada) return; const c = copiaAntigua(); if (!c.toca) return;
  const ult = +store.leer('copiaRecordada', 0) || 0; if (Date.now() - ult < 7 * 864e5) return;
  copiaAvisada = true; store.escribir('copiaRecordada', Date.now());
  setTimeout(() => aviso(c.d == null ? 'Aún no has hecho copia de seguridad: Ajustes → Exportar' : `Hace ${c.d} días de tu última copia: Ajustes → Exportar`), 2500);
}
function exportar() {
  const juegos = {}; JUEGOS.forEach(j => { const e = store.getJuego(j.id); if (e) juegos[j.id] = e; });
  const podios = {}; JUEGOS.forEach(j => { const p = store.leer('podio:' + j.id, null); if (p) podios[j.id] = p; });
  const obj = { app: 'juegos-reunidos', version: 2, fecha: new Date().toISOString(), juegos, stats: stats.todas(), ajustes: aj.ajustes(), logros: logros.conseguidos(), retos: logros.todosRetos(), dias: stats.dias(), podios };
  const a = el('a', { href: URL.createObjectURL(new Blob([JSON.stringify(obj, null, 2)], { type: 'application/json' })), download: `juegos-reunidos-${new Date().toISOString().slice(0, 10)}.json` });
  document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  store.escribir('ultcopia', Date.now());
  msgAj = { t: 'Archivo exportado.', err: false }; vAjustes();
}
// Valida cada partida con el propio módulo del juego (validar / migrarV1) antes de guardarla.
async function ingestar(j, datos, desdeV1) {
  const mod = await j.cargar();
  const d = mod.validar(desdeV1 ? mod.migrarV1(datos) : datos);
  if (!d) return false;
  const r = mod.resumen ? mod.resumen(d) : null;
  store.setJuego(j.id, d, r ? r.texto : null, r ? r.fin : false);
  return true;
}
async function importar(o) {
  o = traducirCopia(o);
  if (!o || typeof o !== 'object' || o.app !== 'juegos-reunidos') throw new Error('El archivo no es una copia de JugamiGO.');
  const got = [];
  for (const j of JUEGOS) {
    try {
      if (o.version === 2 && o.juegos && o.juegos[j.id] && typeof o.juegos[j.id] === 'object') { if (await ingestar(j, o.juegos[j.id].datos, false)) got.push(j.nombre); }
      else if (o.version === 1 && o[j.v1] && typeof o[j.v1] === 'object') { if (await ingestar(j, o[j.v1], true)) got.push(j.nombre); }
    } catch (e) { console.error(e); }
  }
  if (o.version === 2) {
    stats.importar(o.stats); aj.importar(o.ajustes); logros.importar(o.logros); logros.importarRetos(o.retos); stats.importarDias(o.dias); store.escribir('ultcopia', Date.now());
    if (o.podios && typeof o.podios === 'object') for (const j of JUEGOS) importarPodio(j.id, o.podios[j.id]);
  }
  if (!got.length && o.version !== 2) throw new Error('El archivo no contiene partidas reconocibles de JugamiGO.');
  return got;
}
// Podio (top 10) de un juego: se mezcla con el de este dispositivo
function importarPodio(id, P) {
  if (!P || typeof P !== 'object') return;
  const A = store.leer('podio:' + id, {}) || {};
  for (const [v, l] of Object.entries(P)) {
    if (typeof v !== 'string' || v.length > 60 || !Array.isArray(l)) continue;
    const ok = l.filter(x => x && typeof x.n === 'string' && Number.isFinite(x.p) && Number.isFinite(x.f)).map(x => ({ n: x.n.slice(0, 14), p: x.p, f: x.f }));
    const menos = /sprint/i.test(v), todo = [...(A[v] || []), ...ok].filter((x, k, a) => a.findIndex(y => y.f === x.f && y.n === x.n) === k);
    A[v] = todo.sort((a, b) => (menos ? a.p - b.p : b.p - a.p) || a.f - b.f).slice(0, 10);
  }
  store.escribir('podio:' + id, A);
}
// Migración única desde la versión 1 (una sola clave con todo). La clave antigua se conserva como respaldo.
async function migrarV1() {
  if (store.leer('migrado')) return;
  try {
    const raw = localStorage.getItem(V1_KEY);
    if (raw) await importar(JSON.parse(raw));
  } catch (e) { console.error('Migración v1:', e); }
  store.escribir('migrado', true);
}

/* ---------- instalar la app y avisar de versiones nuevas ---------- */
const enApp = () => matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
const esIOS = () => /iphone|ipad|ipod/i.test(navigator.userAgent) && !window.MSStream;
let promptInstalar = null;
function bandaAviso(id, html, botones) {
  document.getElementById(id)?.remove();
  const b = el('div', { class: 'banda', id, role: 'region', 'aria-label': 'Aviso' });
  b.innerHTML = `<span class="banda-t">${html}</span>`;
  const g = el('span', { class: 'banda-b' }); botones.forEach(([t, f, on]) => g.append(el('button', { class: 'btn' + (on ? ' on' : ''), type: 'button', onclick: () => { b.remove(); f(); } }, t))); b.append(g);
  document.body.append(b); return b;
}
async function instalar() { if (!promptInstalar) return; const p = promptInstalar; promptInstalar = null; p.prompt(); try { await p.userChoice; } catch { /* sin respuesta */ } if (ruta().v === 'ajustes') vAjustes(); }
function ofrecerInstalar() {
  if (enApp() || ruta().v === 'juego') return;
  if (Date.now() - (store.leer('instNo', 0) || 0) < 30 * 864e5) return;
  if ((store.leer('visitas', 0) || 0) < 2) return;
  const no = () => store.escribir('instNo', Date.now());
  if (promptInstalar) bandaAviso('bandaInst', '📲 <b>Instala JugamiGO</b> en tu móvil: se abre como una app y funciona sin conexión.', [['Ahora no', no], ['Instalar', instalar, true]]);
  else if (esIOS()) bandaAviso('bandaInst', '📲 Para instalarla: pulsa <b>Compartir ⬆️</b> y «Añadir a pantalla de inicio».', [['Entendido', no, true]]);
}
window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); promptInstalar = e; setTimeout(ofrecerInstalar, 1500); });
window.addEventListener('appinstalled', () => { promptInstalar = null; document.getElementById('bandaInst')?.remove(); aviso('✅ JugamiGO instalada'); });
try { if (!sessionStorage.getItem('jr2:visita')) { sessionStorage.setItem('jr2:visita', '1'); store.escribir('visitas', (store.leer('visitas', 0) || 0) + 1); } } catch { /* sin sessionStorage */ }

/* ---------- arranque ---------- */
// Service worker: comprueba si hay versión nueva en cada arranque y, cuando la nueva toma el control, recarga una vez
// para que se vea al momento (sin esto, la versión nueva solo aparecía en la siguiente apertura de la app).
if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
  const habiaVersion = !!navigator.serviceWorker.controller;
  let recargado = false;
  // Versión nueva: se recarga sola si no estás jugando; en una partida se avisa y se espera (la partida ya está guardada).
  const recargarYa = () => { if (recargado) return; recargado = true; try { sessionStorage.setItem('jr2:upd', '1'); } catch { /* sin sessionStorage */ } location.reload(); };
  let pendiente = false;
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (!habiaVersion || recargado) return;
    if (ruta().v !== 'juego') return recargarYa();
    pendiente = true; bandaAviso('bandaUpd', '✨ <b>Hay una versión nueva.</b> Tu partida está guardada.', [['Luego', () => {}], ['Actualizar', recargarYa, true]]);
  });
  window.addEventListener('hashchange', () => { if (pendiente && ruta().v !== 'juego') recargarYa(); });
  navigator.serviceWorker.register('./sw.js', { updateViaCache: 'none' }).then(r => r.update()).catch(() => {});
  // en segundo plano: guardar las imágenes de los naipes para jugar sin conexión (solo baja las que falten)
  // Como baraja y dorso cambian al azar, se guardan todas las imágenes (~3 MB), salvo con «Ahorro de datos» activado.
  const elegidas = () => [...BARAJAS.espanola, ...BARAJAS.francesa, ...BARAJAS.dorsos, ...BARAJAS.tapetes, ...BARAJAS.fondos].map(x => x.id);
  const ahorro = navigator.connection && navigator.connection.saveData;
  if (!ahorro) navigator.serviceWorker.ready.then(r => setTimeout(() => r.active && r.active.postMessage({ tipo: 'guardar-cartas', ids: elegidas() }), 4000)).catch(() => {});
}
migrarV1().then(render).then(() => {
  try { if (sessionStorage.getItem('jr2:upd')) { sessionStorage.removeItem('jr2:upd'); aviso(`✨ JugamiGO se ha actualizado (versión ${VERSION})`, 3200); } } catch { /* sin sessionStorage */ }
  setTimeout(ofrecerInstalar, 3500);
});
