# Juegos Reunidos 2.0

Sudoku, Nonogram, Damas, Parchís, 3 en raya, Conecta 4, Sopa de letras, Buscaminas, Crucigramas, BlackJack, Klondike, Texas Hold'em, KenKen, Brisca, El Ahorcado, Trivial, Ruleta de la Suerte, Ajedrez, Chinchón, Mus, Hundir la Flota, Rummy de fichas, Juego de la Oca, Cinquillo, Continental, El Rosco, Encadenadas, Serpiente y Bloques, con estadísticas, ajustes, sonido, tema claro/oscuro, copia de seguridad y modo sin conexión (PWA). Sin compilación: JavaScript con módulos nativos.

## Probarla en local
Los módulos JS **no funcionan con doble clic** (`file://`). En esta carpeta:

    python -m http.server 8000

y abre http://localhost:8000. (Cualquier otro servidor estático vale.)

## Publicarla en GitHub Pages
1. Crea un repositorio y sube **el contenido** de esta carpeta a la raíz.
2. Settings → Pages → Deploy from a branch → `main` / `/ (root)`.
3. Antes de cada publicación ejecuta `python tools/generar_sw.py` (actualiza la caché sin conexión).

## Estructura
    index.html · manifest.webmanifest · sw.js
    css/        base.css (global) · cartas.css (para juegos de cartas)
    img/cartas/ imágenes de barajas (espanola/ · francesa/) y dorsos (dorsos/) para 🎨 Apariencia; ver img/cartas/LEEME.md
    icons/      iconos de la app (tools/generar_iconos.py los regenera)
    js/app.js        rutas (#/juego/<id>), inicio, estadísticas, ajustes, importar/exportar
    js/registry.js   LISTA DE JUEGOS: aquí se da de alta cada juego nuevo
    js/core/         aspectos (apariencia), dom, storage, ajustes, stats, sonido, undo, cronometro, cartas, ia/minimax, teclado (teclado emergente arrastrable),
                     duelo (controlador de juegos de 2 jugadores: marcador, CPU, deshacer, pista, guardado)
    js/games/<id>/   index.js + (reglas/generador/ia) + <id>.css de cada juego
    js/games/_plantilla/   punto de partida para un juego nuevo
    data/            palabras/ · crucigramas/ · nonogramas/ (contenido de los juegos)
    tools/           generar_sw.py · generar_barajas.py · optimizar_imagenes.py · generar_iconos.py · verificar_nonogramas.mjs
    tests/motores.mjs   pruebas de los motores:  node tests/motores.mjs
    docs/            AÑADIR-JUEGO.md · MEJORAS-INCLUIDAS.md · HOJA-DE-RUTA.md

## Guardado
Una clave de localStorage por juego (`jr2:juego:<id>`, versión 2). Tus partidas de la versión 1 (`juegos-reunidos-save`) se migran solas la primera vez; la clave antigua no se borra. Los archivos .json exportados de la versión 1 también se pueden importar.

## Barajas e imágenes de cartas
En 🎨 Apariencia de los juegos de cartas se puede elegir una baraja de imágenes (española: Brisca, Chinchón, Mus, Cinquillo · francesa: BlackJack, Klondike, Hold'em, Continental) y un dorso de imagen.
Sube las imágenes a `img/cartas/espanola/<MAZO>/`, `img/cartas/francesa/<MAZO>/` o `img/cartas/dorsos/` (nombres y formato en `img/cartas/LEEME.md`).
GitHub Actions regenera solo `img/cartas/barajas.json` y `sw.js`; en local: `python tools/generar_barajas.py && python tools/generar_sw.py`.
