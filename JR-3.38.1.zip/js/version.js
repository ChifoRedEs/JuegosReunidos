// Versión de Juegos Reunidos. Se muestra al pie de ⚙️ Ajustes.
// Al publicar cambios: sube el número aquí y añade una entrada en «Historial de versiones» del README.md.
// MAYOR (cambios grandes en toda la app) · MENOR (juegos o funciones nuevas) · PARCHE (arreglos)
export const VERSION = '3.38.1';
export const FECHA = '2026-10-26';
