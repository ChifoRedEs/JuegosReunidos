import { pieMenu } from '../../core/pie.js';
import { grupoFigura, figuraTintada } from '../../core/figuras.js';
import { $, esc, rnd } from '../../core/dom.js';
import { crearDado3D, grupoDado } from '../../core/dado3d.js';
import { PC, PNAME, PSTART, PSAFE, PHOUSE, PTRACK, PTRI, PCORR, PIPS, pXY, pKey } from './tablero.js';
import { nombre, actual, esCPU, nuevaPartida, legales, tirar, mover, siguiente, mejorJugada, fichasDe, equipo, nombreEquipo, COMPANERO } from './reglas.js';
import { gruposFichas, estilo } from '../../core/fichas.js';
import { grupoFondo, grupoPersonaje, emojiPersonaje } from '../../core/aspectos.js';

const VEL = { rapida: .5, normal: 1, lenta: 1.7 };
let P = null, api = null, asp = null, rootEl = null, modo = 'setup', timer = null, ivDado = null, ivAnim = null, rodando = false, ptsMov = [], ultFoco = '', D3 = null, tokD = 0;
let cfgSetup = { am: 'h', az: 'c', ro: 'c', ve: 'c' }, nombres = {}, libre = false, parejas = false;
const velMult = () => VEL[api.pref('vel', 'normal')] || 1;
let zoomN = 1;
const ZOOMS = [1, 1.4, 1.8];                                   // Todo → Grande → Muy grande (doble toque en el tablero)
const zoom = () => zoomN;
const forma = () => (asp && asp.valores.fichas) || 'canica';
// Vista 3D (Three.js): opcional, con vuelta automática al tablero SVG si no hay WebGL
let V3 = null, hay3d = false, modo3d = false, forzar2d = false, tok3 = 0;
const quiere3D = () => hay3d && !forzar2d && !!asp && (asp.valores.vista || '2d') === '3d';
const mundo = v => v / 10 - 9.5;
function cerrar3D() { tok3++; if (V3) { try { V3.destruir(); } catch { /* nada */ } V3 = null; } }

/* ---------- validación / migración ---------- */
export function validar(x) {
  if (!x || typeof x !== 'object' || !Array.isArray(x.order) || x.order.length < 2 || x.order.length > 4 || new Set(x.order).size !== x.order.length || !x.order.every(c => PC.includes(c))) return null;
  if (!x.cfg || typeof x.cfg !== 'object' || !x.pieces || typeof x.pieces !== 'object' || !x.order.every(c => ['h', 'c'].includes(x.cfg[c]) && Array.isArray(x.pieces[c]) && x.pieces[c].length === 4 && x.pieces[c].every(p => Number.isInteger(p) && p >= -1 && p <= 71))) return null;
  const ok = Number.isInteger(x.turn) && x.turn >= 0 && x.turn < x.order.length && ['roll', 'move', 'pass', 'over'].includes(x.phase)
    && Number.isInteger(x.step) && x.step >= 0 && x.step <= 20 && ['die', 'bonus', 'libre'].includes(x.kind)
    && Array.isArray(x.pend) && x.pend.every(v => v === 0 || v === 10 || v === 20) && Number.isInteger(x.sixes) && x.sixes >= 0 && x.sixes < 3
    && (x.die == null || (Number.isInteger(x.die) && x.die >= 1 && x.die <= 6)) && (x.lastMoved == null || [0, 1, 2, 3].includes(x.lastMoved))
    && (x.phase !== 'over' || x.order.includes(x.winner));
  if (!ok) return null;
  const names = {}; if (x.names && typeof x.names === 'object') for (const c of x.order) if (typeof x.names[c] === 'string') names[c] = x.names[c].slice(0, 14);
  const cfg = {}; PC.forEach(c => { cfg[c] = x.order.includes(c) ? x.cfg[c] : null; });
  return { cfg, names, order: x.order.slice(), pieces: Object.fromEntries(x.order.map(c => [c, x.pieces[c].slice()])), turn: x.turn, phase: x.phase, die: x.die ?? null,
    step: x.step, kind: x.kind, pend: x.pend.slice(), sixes: x.sixes, again: !!x.again, lastMoved: x.lastMoved ?? null, winner: x.phase === 'over' ? x.winner : null,
    salidaLibre: !!x.salidaLibre, primera: Object.fromEntries(x.order.map(c => [c, !!(x.primera && x.primera[c])])), extraSalida: !!x.extraSalida,
    parejas: !!x.parejas && x.order.length === 4, lastC: x.order.includes(x.lastC) ? x.lastC : null };
}
export const migrarV1 = d => d;
export function resumen(d) {
  const nm = c => (d.names && d.names[c]) || PNAME[c];
  if (d.phase === 'over') return { texto: d.parejas ? `Ganaron ${nm(d.winner)} y ${nm(COMPANERO[d.winner])}` : `Ganó ${nm(d.winner)}`, fin: true };
  return { texto: `${d.parejas ? 'Por parejas' : d.order.length + ' jugadores'} · turno de ${nm(d.order[d.turn])}`, fin: false };
}
function restaurar(d) {
  P = { ...d, note: '', log: ['Partida cargada.'], moves: [], ov: null, anim: false };
  if (P.phase === 'move') { P.moves = legales(P, fichasDe(P, actual(P)), P.step, P.kind); if (!P.moves.length) { P.phase = 'pass'; P.note = 'Sin movimientos posibles.'; } }
  if (P.phase === 'pass') P.note = P.note || 'Continuando…';
}
function guardar() {
  if (!P) return;
  const d = { cfg: P.cfg, names: P.names, order: P.order, pieces: P.pieces, turn: P.turn, phase: P.phase, die: P.die, step: P.step, kind: P.kind, pend: P.pend, sixes: P.sixes, again: P.again, lastMoved: P.lastMoved, winner: P.winner, salidaLibre: P.salidaLibre, primera: P.primera, extraSalida: P.extraSalida, parejas: !!P.parejas, lastC: P.lastC || null };
  const r = resumen(d); api.guardar(d, r.texto, r.fin);
}

/* ---------- ciclo de vida ---------- */
const DEFS_ASPECTO = [
  ...grupoDado(),
  { clave: 'vista', titulo: 'Vista del tablero', icono: '🧊', def: '2d', opciones: [{ id: '3d', nombre: '🧊 3D' }, { id: '2d', nombre: '🔲 2D clásica' }] },
  { ...{ ...grupoFondo('#pzView'), def: 't-n-mesa-juegos-1' }, tt: true }, grupoPersonaje('Personajes (tus fichas)'),
  { clave: 'tablero', tt: true, titulo: 'Tablero', def: 'cielo', opciones: [{ id: 'cielo', nombre: 'Cielo', sw: ['#EAF1FF', '#fff'] }, { id: 'madera', nombre: 'Madera', sw: ['#C98F53', '#FFEFD0'] }, { id: 'oscuro', nombre: 'Noche', sw: ['#0E1430', '#232F63'] }, { id: 'caramelo', nombre: 'Caramelo', sw: ['#FFD3EA', '#FFF6FB'] }] },
  grupoFigura({ clave: 'fichas', titulo: 'Figura de las fichas', def: 'canica' }),
  ...gruposFichas({ pocos: true, titulo: 'Fichas', tituloEstilos: 'Estilos de Fichas', icono: '🎲', lados: ['Amarillo', 'Azul', 'Rojo', 'Verde'], formas: false }),
];
export async function mount(root, a) {
  api = a; rootEl = root; rodando = false; ultFoco = ''; forzar2d = false; modo3d = false;
  try { const b3 = await import('../../core/escena3d.js'); hay3d = b3.hayWebGL(); } catch { hay3d = false; }
  asp = api.aspecto(DEFS_ASPECTO, () => {
    if (D3) D3.estilo(asp.valores);
    aplicarFichas();
    if (modo === 'setup' || !P) { if (rootEl) rSetup(); return; }
    if (modo3d !== quiere3D()) { rJuego(); ultFoco = ''; pintarJuego(); return; }
    if (modo3d) { if (V3) V3.recolor(); ultFoco = ''; pintarJuego(); return; }
    const t = $('#pzTab'); if (t) t.style.width = zoom() * 100 + '%';
    ultFoco = ''; pintarJuego();
  });
  await api.css(new URL('../../../css/fichas.css', import.meta.url));
  await api.css(new URL('./partxis.css', import.meta.url));
  const c0 = api.pref('cfg', null);
  if (c0 && PC.every(c => ['h', 'c', null].includes(c0[c] ?? null)) && PC.filter(c => c0[c]).length >= 2) cfgSetup = { am: c0.am ?? null, az: c0.az ?? null, ro: c0.ro ?? null, ve: c0.ve ?? null };
  libre = !!api.pref('libre', false); parejas = !!api.pref('parejas', false);
  const n0 = api.pref('names', {}); nombres = n0 && typeof n0 === 'object' ? { ...n0 } : {};
  zoomN = ZOOMS.includes(+api.pref('zoom', 1)) ? +api.pref('zoom', 1) : 1;
  root.addEventListener('pointerup', dobleToque);
  root.addEventListener('click', clic); root.addEventListener('input', alEscribir); root.addEventListener('change', alCambiar);
  api.barra({ nueva: () => { if (P && P.phase !== 'over' && !api.confirmar('¿Abandonar la partida actual?')) return; iniciarPartida(); },
    salir: () => { clearTimeout(timer); clearInterval(ivDado); clearInterval(ivAnim); rodando = false; P = null; api.borrar(); modo = 'setup'; location.hash = '#/cat/tablero'; },
    pausar: () => { clearTimeout(timer); },
    reanudar: () => { if (P && P.phase !== 'over') drive(); },
    config: { valores: () => ({ ...Object.fromEntries(PC.map(c => [c, cfgSetup[c] || 'n'])), parejas, libre, vel: api.pref('vel', 'normal') }), grupos: v => [...PC.map(c => ({ clave: c, titulo: `Jugador ${PNAME[c]}${nombres[c] ? ' · ' + nombres[c] : ''}`, opciones: [['h', 'Persona'], ['c', 'CPU'], ['n', 'Nadie']] })), { clave: 'parejas', titulo: 'Por parejas (con 4 jugadores)', opciones: [[true, 'Sí'], [false, 'No']], visible: PC.every(c => v[c] !== 'n') }, { clave: 'libre', titulo: 'Salida libre', opciones: [[true, 'Sí'], [false, 'No']] }, { clave: 'vel', titulo: 'Velocidad CPU', opciones: [['rapida', 'Rápida'], ['normal', 'Normal'], ['lenta', 'Lenta']] }], aplicar: v => { if (PC.filter(c => v[c] !== 'n').length < 2) { api.aviso('Hacen falta al menos 2 jugadores'); return; } PC.forEach(c => { cfgSetup[c] = v[c] === 'n' ? null : v[c]; }); api.setPref('cfg', cfgSetup); libre = !!v.libre; parejas = !!v.parejas; api.setPref('libre', libre); api.setPref('parejas', parejas); api.setPref('vel', v.vel); iniciarPartida(); } } });
  api.menu([{ texto: 'Nueva partida', accion: nuevaSetup }, { texto: '🎨 Apariencia', accion: () => asp.abrir() }, { texto: '📖 Reglas', accion: reglas }]);
  const g = api.cargar();
  if (g) { restaurar(g); modo = 'juego'; rJuego(); pintarJuego(); drive(); }
  else { P = null; modo = 'setup'; rSetup(); }
}
export function unmount() {
  clearTimeout(timer); clearInterval(ivDado); clearInterval(ivAnim); timer = ivDado = ivAnim = null; rodando = false; quitarDado(); cerrar3D(); modo3d = false;
  if (rootEl) { rootEl.removeEventListener('pointerup', dobleToque); rootEl.removeEventListener('click', clic); rootEl.removeEventListener('input', alEscribir); rootEl.removeEventListener('change', alCambiar); }
  P = null; asp = null;
}

/* ---------- cámara: con zoom el tablero se desplaza solo hacia donde ocurre la acción ---------- */
function enfocar(pts, suave = true) {
  if (modo3d) return;
  const v = $('#pzView'), t = $('#pzTab'); if (!v || !t || zoom() <= 1 || !pts.length) return;
  const k = t.clientWidth / 190, xs = pts.map(p => p[0]), ys = pts.map(p => p[1]);
  const cx = (Math.min(...xs) + Math.max(...xs)) / 2 * k, cy = (Math.min(...ys) + Math.max(...ys)) / 2 * k;
  v.scrollTo({ left: Math.max(0, cx - v.clientWidth / 2), top: Math.max(0, cy - v.clientHeight / 2), behavior: suave ? 'smooth' : 'auto' });
}
function seguir(x, y) {
  if (modo3d) return;
  const v = $('#pzView'), t = $('#pzTab'); if (!v || !t || zoom() <= 1) return;
  const k = t.clientWidth / 190, px = x * k - v.scrollLeft, py = y * k - v.scrollTop, mx = v.clientWidth * .22, my = v.clientHeight * .22;
  if (px < mx || px > v.clientWidth - mx || py < my || py > v.clientHeight - my) enfocar([[x, y]], false);
}
const ptsJugador = c => { const l = P.pieces[c].map((p, i) => [p, i]).filter(([p]) => p >= 0 && p < 71).map(([p, i]) => pXY(c, p, i)); return l.length ? l : [pXY(c, 0, 0)]; };

/* ---------- flujo de juego (el motor está en reglas.js; aquí van temporizadores y animación) ---------- */
function drive() {
  if (!P || P.phase === 'over' || P.anim || rodando) return;
  const c = actual(P), t = ms => ms * velMult();
  clearTimeout(timer);
  if (P.phase === 'pass') timer = setTimeout(() => { if (!P) return; siguiente(P); guardar(); pintarJuego(); drive(); }, t(1200));
  else if (esCPU(P, c) && P.phase === 'roll') timer = setTimeout(iniciarTirada, t(700));
  else if (esCPU(P, c) && P.phase === 'move') timer = setTimeout(() => { if (P && P.phase === 'move') jugarMov(mejorJugada(P)); }, t(650));
}
function iniciarTirada() {
  if (!P || P.phase !== 'roll' || rodando || P.anim) return;
  clearTimeout(timer); rodando = true; api.sonido('dado'); api.vibrar(10);
  const c = actual(P), v = 1 + rnd(6), ms = Math.round(900 * velMult());
  pintarJuego();
  if (D3) D3.color(getComputedStyle(rootEl).getPropertyValue('--pz-' + c).trim());
  const fin = () => { rodando = false; if (!P) return; tirar(P, v); guardar(); pintarJuego(); drive(); };
  if (D3) D3.tirar([v], ms).then(fin); else ivDado = setTimeout(() => { ivDado = null; fin(); }, Math.min(ms, 600));
}
function jugarMov(m) {
  if (!P || P.phase !== 'move' || P.anim || !m) return;
  clearTimeout(timer);
  const info = mover(P, m); guardar();
  if (!info) return;
  api.sonido(info.cap ? 'captura' : 'mover'); api.vibrar(info.cap ? 25 : 8);
  if (P.phase === 'over') {
    const humanos = P.order.filter(c => !esCPU(P, c));
    // por parejas gana todo el equipo; si hay humanos en los dos equipos, la partida solo cuenta como jugada
    const gana = c => P.parejas ? equipo(c) === equipo(P.winner) : c === P.winner, eqH = new Set(humanos.map(equipo));
    const res = P.parejas ? (eqH.size === 1 ? (gana(humanos[0]) ? 'victoria' : 'derrota') : 'partida') : humanos.length === 1 ? (gana(humanos[0]) ? 'victoria' : 'derrota') : 'partida';
    api.registrar({ res, variante: P.parejas ? 'Por parejas' : `${P.order.length} jugadores` });
    api.sonido(res === 'derrota' ? 'perder' : 'ganar');
  }
  animar(info, () => { pintarJuego(); drive(); });
}
function animar(info, fin) {
  const pasos = []; if (info.from === -1) pasos.push(0); else for (let p = info.from + 1; p <= info.to; p++) pasos.push(p);
  const k0 = info.c + ',' + info.i;
  P.anim = true; P.ov = { [k0]: info.from };
  if (info.cap) P.ov[info.cap.c + ',' + info.cap.i] = info.cap.p;       // la ficha comida se queda hasta que llega la otra
  const tab = $('#pzTab'); let k = 0;
  enfocar([pXY(info.c, info.from, info.i), pXY(info.c, info.to, info.i)]);
  clearInterval(ivAnim);
  ivAnim = setInterval(() => {
    if (!P) { clearInterval(ivAnim); return; }
    P.ov[k0] = pasos[k]; if (modo3d) pintar3D(); else if (tab) tab.innerHTML = pBoard(); seguir(...pXY(info.c, pasos[k], info.i)); k++;
    if (k >= pasos.length) { clearInterval(ivAnim); ivAnim = null; setTimeout(() => { if (!P) return; P.anim = false; P.ov = null; fin(); }, 120 * velMult()); }
  }, Math.max(45, Math.round(110 * velMult())));
}

/* ---------- pantallas ---------- */
function nuevaSetup() {
  if (P && P.phase !== 'over' && !api.confirmar('¿Abandonar la partida actual?')) return;
  clearTimeout(timer); clearInterval(ivDado); clearInterval(ivAnim); rodando = false; P = null; api.borrar(); modo = 'setup'; rSetup();
}
function rSetup() {
  cerrar3D(); modo3d = false;
  const n = PC.filter(c => cfgSetup[c]).length;
  rootEl.innerHTML = `
    <p class="note">Elige quién juega con cada color y, si quieres, escribe un nombre. Hacen falta al menos 2 jugadores; varias personas pueden jugar en el mismo dispositivo por turnos.</p>
    ${PC.map(c => `<div class="jugfila" style="--c:var(--pz-${c})"><span class="jf-dot"></span>
      <input class="nom" data-name="${c}" maxlength="14" placeholder="${PNAME[c]}" value="${esc(nombres[c] || '')}" aria-label="Nombre del jugador ${PNAME[c]}">
      <div class="seg">${[['h', 'Persona'], ['c', 'CPU'], ['n', 'Nadie']].map(([t, l]) => `<button class="btn ${(cfgSetup[c] || 'n') === t ? 'on' : ''}" data-cfg="${c},${t}">${l}</button>`).join('')}</div></div>`).join('')}
    <label class="chk"><input type="checkbox" id="pzParejas" ${parejas && n === 4 ? 'checked' : ''} ${n === 4 ? '' : 'disabled'}><span><b>Por parejas</b> (con 4 jugadores): <b>Amarillo y Rojo</b> contra <b>Azul y Verde</b>. No se come al compañero y, cuando uno mete sus 4 fichas, sigue tirando para mover las de su pareja. Gana la pareja que mete las 8.</span></label>
    <label class="chk"><input type="checkbox" id="pzLibre" ${libre ? 'checked' : ''}><span><b>Salida libre</b>: si no tienes ninguna ficha en juego, sales con una ficha con cualquier número (no hace falta un 5). Y si en tu primera tirada sacas un 5, sacas dos fichas de casa.</span></label>
    <div class="bar"><span class="lbl">Velocidad CPU</span>${velBotones()}</div>
    ${pieMenu({ deshabilitado: n < 2, nota: n < 2 ? 'Elige al menos 2 jugadores.' : '' })}
    <details><summary>Reglas</summary>${listaReglas()}</details>
    <div class="pzv"><div class="pzb">${pBoard(true)}</div></div>`;
}
const velBotones = () => `<div class="seg">${[['rapida', 'Rápida'], ['normal', 'Normal'], ['lenta', 'Lenta']].map(([k, l]) => `<button class="btn ${api.pref('vel', 'normal') === k ? 'on' : ''}" data-vel="${k}">${l}</button>`).join('')}</div>`;
function listaReglas() {
  return `<ul>
    <li>Sacas ficha de casa con un 5. Si puedes sacar, es obligatorio. Con la opción <b>Salida libre</b> (al crear la partida), si no tienes fichas en juego sales con una ficha con cualquier número, y con un 5 en tu primera tirada sacas dos.</li>
    <li>Con un 6 vuelves a tirar. Si no te quedan fichas en casa, el 6 cuenta 7.</li>
    <li>Tres 6 seguidos: la última ficha movida vuelve a casa (salvo si está en el pasillo).</li>
    <li>Comer una ficha rival te da 20 casillas extra; meter una en meta, 10.</li>
    <li>En los seguros (casillas con estrella) y en las salidas no se come.</li>
    <li>Dos fichas del mismo color forman barrera: nadie puede pasar. Con un 6 debes abrirla.</li>
    <li>A meta se entra con el número exacto. Gana quien mete antes sus 4 fichas.</li>
    <li><b>Por parejas</b> (4 jugadores): Amarillo y Rojo contra Azul y Verde. Al compañero no se le come; quien acaba antes sigue tirando y mueve las fichas de su pareja. Gana la pareja que mete sus 8 fichas.</li>
    <li>Para mover, toca una ficha resaltada <b>o</b> la casilla de destino marcada (si ahí se come una ficha verás un destello).</li>
    <li>En 🎨 Apariencia eliges tapete, tablero, colores y estilo de las fichas. En la vista 2D, un doble toque en el tablero lo amplía (Todo → Grande → Muy grande → Todo) y con zoom se desplaza solo hacia la acción.</li></ul>`;
}
function rJuego() {
  quitarDado(); cerrar3D(); modo3d = quiere3D();
  rootEl.innerHTML = `
    ${modo3d ? '<div class="e3d" id="pzView"></div><div id="pzTab" hidden></div>' : `<div class="pzv" id="pzView"><div class="pzb" id="pzTab" style="width:${zoom() * 100}%"></div></div>`}
    <div class="dadozona" id="pzDado"></div>
    <div class="pbar"><div><div class="msg" id="pzMsg" role="status" aria-live="polite"></div><div class="note" id="pzSub"></div></div></div>
    <ul class="plog" id="pzLog"></ul>${api.barraHtml()}`;
  if (modo3d) iniciar3D();
  iniciarDado();
}
function quitarDado() { tokD++; if (D3) { D3.destruir(); D3 = null; } }
async function iniciarDado() {
  const t = ++tokD, host = $('#pzDado'); if (!host) return;
  const d = await crearDado3D(host, { n: 1, etiqueta: 'Dado: toca para tirar', alClic: () => { if (P && P.phase === 'roll' && !esCPU(P, actual(P))) iniciarTirada(); } });
  if (t !== tokD || !d) { if (d) d.destruir(); return; }
  D3 = d; D3.estilo(asp.valores); if (P) pintarJuego();
}
async function iniciar3D() {
  const t = ++tok3, volver = () => { if (t === tok3 && rootEl && modo === 'juego') { forzar2d = true; rJuego(); pintarJuego(); } };
  try {
    const b3 = await import('../../core/escena3d.js'), { crearParchis3D } = await import('./vista3d.js'); if (t !== tok3 || !rootEl) return;
    const host = $('#pzView'); if (!host) return;
    const v = await crearParchis3D(host, { alPieza: tocarPieza, alDestino: tocarDest, alDado: () => { if (P && P.phase === 'roll' && !esCPU(P, actual(P))) iniciarTirada(); } });
    if (t !== tok3 || !rootEl) { v.destruir(); return; }
    b3.botonesCamara(host, v.E); V3 = v; pintarJuego(); if (P && !P.anim) pintarDado(P.die, P.phase === 'over' ? P.winner : actual(P), false);
  } catch (e) { console.error(e); volver(); }
}
const humanoMueve = () => !!P && P.phase === 'move' && !esCPU(P, actual(P)) && !P.anim;
function tocarPieza(c, i) { if (!humanoMueve()) return; const m = P.moves.find(m => m.c === c && m.i === +i); if (m) jugarMov(m); }
function tocarDest(to) { if (!humanoMueve()) return; const m = P.moves.find(m => m.to === +to); if (m) jugarMov(m); }
function pintar3D() {
  if (!V3 || !P) return;
  V3.fichas(estilo(asp.valores));
  const cur = P.phase !== 'over' ? actual(P) : null, human = !!cur && humanoMueve(), emo = emojiPersonaje(asp);
  ptsMov = [];
  const mv = new Set(human ? P.moves.map(m => m.c + m.i) : []), dest = [], vistos = new Set();
  if (human) for (const m of P.moves) {
    const key = m.c + m.to; ptsMov.push(pXY(m.c, m.from, m.i), pXY(m.c, m.to, m.i)); if (vistos.has(key)) continue; vistos.add(key);
    const [x, y] = pXY(m.c, m.to, m.i); dest.push({ x: mundo(x), z: mundo(y), c: m.c, to: m.to, cap: !!m.cap });
  }
  const grp = {}, list = [];
  for (const c of P.order) P.pieces[c].forEach((_, i) => { const p = posVis(c, i); const k = p >= 0 && p < 71 ? pKey(c, p) : null; if (k) grp[k] = (grp[k] || 0) + 1; list.push({ c, i, p, k }); });
  const idx = {};
  const piezas = list.map(o => {
    const [x, y] = pXY(o.c, o.p, o.i), dos = o.k && grp[o.k] === 2, n = o.k ? (idx[o.k] = (idx[o.k] || 0) + 1) - 1 : 0;
    return { c: o.c, i: o.i, x: mundo(x) + (dos ? (n ? .33 : -.33) : 0), z: mundo(y), esc: (o.p === 71 ? 3 : o.p === -1 ? 5.1 : dos ? 3.3 : 4.6) / 4.6, mov: mv.has(o.c + o.i), emoji: emo && !esCPU(P, o.c) ? emo : '', img: figuraTintada(forma(), hexDe(o.c), refrescar) || '' };
  });
  const casas = {}; for (const c of PC) { const cf = P.cfg[c]; casas[c] = { on: !!cf, etq: cf ? (P.names[c] || (cf === 'c' ? 'CPU' : 'Persona')) : '' }; }
  V3.pintar({ piezas, dest, turno: cur, casas, forma: forma() });
}
function pintarDado(v, c, roda) {
  if (!D3 || roda) return;
  D3.color(getComputedStyle(rootEl).getPropertyValue('--pz-' + c).trim());
  D3.poner([v || null]);
}
function pintarJuego() {
  if (modo !== 'juego' || !P || !$('#pzTab')) return;
  aplicarFichas();
  if (!P.anim) { if (modo3d) pintar3D(); else $('#pzTab').innerHTML = pBoard(); }
  const over = P.phase === 'over', c = over ? P.winner : actual(P), who = nombre(P, c) + (esCPU(P, c) ? ' (CPU)' : '');
  const humano = !over && !esCPU(P, c);
  const msg = over ? (P.parejas ? `¡Ganan ${nombreEquipo(P, P.winner)}!` : `¡Gana ${nombre(P, P.winner)}!`) : rodando ? `${who} tira…` : P.phase === 'pass' ? P.note : P.phase === 'roll' ? (esCPU(P, c) ? `${who} va a tirar…` : `${who}: tira el dado.`) : (esCPU(P, c) ? `${who} está pensando…` : `${who}: toca una ficha resaltada.`);
  const sub = over || rodando ? '' : P.phase === 'move' ? (P.kind === 'libre' ? (P.step ? `Salida libre: con el ${P.step} sacas una ficha de casa.` : 'Segunda salida: saca otra ficha de casa.') : P.kind === 'bonus' ? `Premio: cuenta ${P.step}.` : P.step === 7 ? 'El 6 cuenta 7: no quedan fichas en casa.' : `Mueve ${P.step}.`) : '';
  if (!rodando) pintarDado(P.die, c, false);
  const m = $('#pzMsg'); m.textContent = msg; m.className = 'msg' + (over ? ' win' : '');
  $('#pzSub').textContent = sub;
  if (D3) D3.activar(humano && P.phase === 'roll' && !rodando && !P.anim, 'Toca el dado para tirar');
  $('#pzLog').innerHTML = P.log.map(l => `<li>${esc(l)}</li>`).join('');
  const clave = `${P.turn}|${P.phase}|${P.step}|${P.order.length}`;
  if (!P.anim && !over && clave !== ultFoco) {
    ultFoco = clave;
    if (P.phase === 'move' && humano && ptsMov.length) enfocar(ptsMov);
    else if (P.phase === 'roll') enfocar(ptsJugador(c));
  }
}

/* ---------- tablero SVG ---------- */
const posVis = (c, i) => (P.ov && P.ov[c + ',' + i] !== undefined ? P.ov[c + ',' + i] : P.pieces[c][i]);
const estrellaPts = (x, y, R, r) => Array.from({ length: 10 }, (_, k) => { const a = -Math.PI / 2 + k * Math.PI / 5, q = k % 2 ? r : R; return (x + Math.cos(a) * q).toFixed(2) + ',' + (y + Math.sin(a) * q).toFixed(2); }).join(' ');
// 🎲 Fichas: color de cada jugador (variables --pz-am/az/ro/ve), tamaño (2D y 3D) y textura (3D)
const ESC_FX = () => estilo(asp.valores).esc;
function aplicarFichas() {
  const r = rootEl; if (!r || !asp) return; const e = estilo(asp.valores);
  [['am', e.hex], ['az', e.hex2], ['ro', e.hex3], ['ve', e.hex4]].forEach(([c, h]) => h ? r.style.setProperty('--pz-' + c, h) : r.style.removeProperty('--pz-' + c));
}
const hexDe = c => (rootEl && getComputedStyle(rootEl).getPropertyValue('--pz-' + c).trim()) || ({ am: '#F2B600', az: '#2F7BD9', ro: '#E04545', ve: '#2EA35B' })[c];
let refTimer = 0;
const refrescar = () => { clearTimeout(refTimer); refTimer = setTimeout(() => { if (!rootEl) return; if (P) pintarJuego(); else { const t = rootEl.querySelector('.pzb'); if (t) t.innerHTML = pBoard(true); } }, 30); };
function ficha(f, c, x, y, r) {
  r *= ESC_FX();
  const col = `style="fill:var(--pz-${c})"`, st = 'stroke="rgba(0,0,0,.55)" stroke-width=".8" stroke-linejoin="round"';
  const emo = emojiPersonaje(asp);     // «Personajes»: tus fichas (las de los jugadores humanos) llevan el emoji sobre su color
  if (emo && P && !esCPU(P, c)) return `<circle cx="${x}" cy="${y}" r="${r}" ${col} ${st}/><text x="${x}" y="${y + r * .04}" font-size="${(r * 1.5).toFixed(2)}" text-anchor="middle" dominant-baseline="central" style="pointer-events:none">${emo}</text>`;
  const url = figuraTintada(f, hexDe(c), refrescar);
  if (url) { const w = r * 2.5; return `<ellipse cx="${x}" cy="${y + r * .95}" rx="${r * .8}" ry="${r * .22}" fill="#000" opacity=".22"/><image href="${url}" x="${(x - w / 2).toFixed(2)}" y="${(y - w * .62).toFixed(2)}" width="${w.toFixed(2)}" height="${w.toFixed(2)}" preserveAspectRatio="xMidYMid meet" style="pointer-events:none"/>`; }
  return `<circle cx="${x}" cy="${y}" r="${r}" ${col} ${st}/>`;      // mientras se tiñe la figura
}
function pBoard(preview) {
  const cur = P && P.phase !== 'over' ? actual(P) : null, human = !!P && P.phase === 'move' && !esCPU(P, cur) && !P.anim, f = forma();
  let s = `<svg class="pzs" viewBox="0 0 190 190" role="img" aria-label="Tablero de parchís"><rect class="bg" width="190" height="190"/>`;
  // casas pequeñas y discretas: el protagonismo es del recorrido
  for (const c of PC) {
    const [hx, hy] = PHOUSE[c], cf = P ? P.cfg[c] : cfgSetup[c], on = !!cf;
    const etiqueta = on ? ((P ? P.names[c] : nombres[c]) || (cf === 'c' ? 'CPU' : 'Persona')) : '';
    s += `<g opacity="${on ? 1 : .3}"><rect x="${hx + 4}" y="${hy + 4}" width="72" height="72" rx="14" style="fill:var(--pz-${c});fill-opacity:.12"/>
      ${cur === c ? `<rect class="turn" x="${hx + 4}" y="${hy + 4}" width="72" height="72" rx="14" fill="none" stroke-width="2.4" style="stroke:var(--pz-${c})"/>` : ''}
      <circle cx="${hx + 40}" cy="${hy + 40}" r="21" style="fill:none;stroke:var(--pz-${c})" stroke-width="1.6"/><image href="img/partxis/nido.webp" x="${hx + 20}" y="${hy + 20}" width="40" height="40" preserveAspectRatio="xMidYMid meet" style="pointer-events:none"/>
      <text class="pzt" x="${hx + 40}" y="${hy + 70}" text-anchor="middle" font-size="6.5" font-weight="800">${esc(etiqueta)}</text></g>`;
  }
  // recorrido: casillas grandes, redondeadas y llamativas
  for (let n = 1; n <= 68; n++) {
    const [r, c] = PTRACK[n], st = PC.find(k => PSTART[k] === n), x = c * 10, y = r * 10;
    s += `<rect x="${x + .6}" y="${y + .6}" width="8.8" height="8.8" rx="2.4" stroke-width=".7" style="stroke:var(--pz-line);fill:${st ? `var(--pz-${st})` : 'var(--pz-cell)'}"/>`;
    if (PSAFE.has(n) && !st) s += `<image href="img/partxis/seguro.webp" x="${x + 1.2}" y="${y + 1.2}" width="7.6" height="7.6" style="pointer-events:none"/>`;
    if (st) s += `<image href="img/partxis/salida.webp" x="${x + 1}" y="${y + 1}" width="8" height="8" style="pointer-events:none"/>`;
  }
  for (const c of PC) for (let k = 1; k <= 7; k++) { const [r, cc] = PCORR(c, k); s += `<rect x="${cc * 10 + .6}" y="${r * 10 + .6}" width="8.8" height="8.8" rx="2.4" stroke-width=".7" style="stroke:var(--pz-line);fill:var(--pz-${c});fill-opacity:${(.32 + k * .08).toFixed(2)}"/>`; }
  for (const c of PC) s += `<polygon points="${PTRI[c]}" stroke-width=".8" stroke-linejoin="round" style="stroke:var(--pz-cell);fill:var(--pz-${c})"/>`;
  if (!P) return s + '</svg>';
  ptsMov = [];
  const mvSet = new Set(human ? P.moves.map(m => m.c + m.i) : []);
  if (human) {           // casillas de destino: ficha fantasma + anillo giratorio (+💥 si se come)
    const seen = new Set();
    for (const m of P.moves) {
      const key = m.c + m.to; ptsMov.push(pXY(m.c, m.from, m.i), pXY(m.c, m.to, m.i));
      if (seen.has(key)) continue; seen.add(key);
      const [x, y] = pXY(m.c, m.to, m.i);
      s += `<g data-dest="${m.to}" style="cursor:pointer"><circle class="dst" cx="${x}" cy="${y}" r="6.3" style="stroke:var(--pz-${m.c});fill:var(--pz-${m.c});fill-opacity:.18"/><g opacity=".5">${ficha(f, m.c, x, y, m.to === 71 ? 3 : 4.2)}</g>
        ${m.cap ? `<image href="img/partxis/captura.webp" x="${x + 1.5}" y="${y - 9}" width="8" height="8" style="pointer-events:none"/>` : ''}<circle cx="${x}" cy="${y}" r="8" fill="transparent"/></g>`;
    }
  }
  // fichas: dos en la misma casilla se dibujan una al lado de la otra
  const grp = {}, list = [];
  for (const c of P.order) P.pieces[c].forEach((_, i) => {
    const p = posVis(c, i);
    if (p >= 0 && p < 71) { const k = pKey(c, p); grp[k] = grp[k] || []; list.push({ c, i, p, k, n: grp[k].length }); grp[k].push(1); }
    else { const [x, y] = pXY(c, p, i); list.push({ c, i, p, x, y }); }
  });
  list.forEach(o => { if (o.k) { const [x, y] = pXY(o.c, o.p, o.i), two = grp[o.k].length === 2; o.x = x + (two ? (o.n ? 3.3 : -3.3) : 0); o.y = y; o.two = two; } });
  list.sort((a, b) => mvSet.has(a.c + a.i) - mvSet.has(b.c + b.i));
  for (const o of list) {
    const mv = mvSet.has(o.c + o.i), r = o.p === 71 ? 3 : o.p === -1 ? 5.1 : o.two ? 3.3 : 4.6;
    s += `<g ${mv ? `data-pc="${o.c},${o.i}" style="cursor:pointer"` : ''}>${mv ? `<circle class="mv" cx="${o.x}" cy="${o.y}" r="${r + 2.2}"/>` : ''}${ficha(f, o.c, o.x, o.y, r)}${mv ? `<circle cx="${o.x}" cy="${o.y}" r="${r + 3.5}" fill="transparent"/>` : ''}</g>`;
  }
  return s + '</svg>';
}

/* ---------- entrada ---------- */
function alCambiar(e) {
  if (e.target.id === 'pzLibre') { libre = e.target.checked; api.setPref('libre', libre); }
  if (e.target.id === 'pzParejas') { parejas = e.target.checked; api.setPref('parejas', parejas); }
}
function alEscribir(e) {
  const c = e.target.dataset && e.target.dataset.name; if (!c) return;
  nombres[c] = e.target.value.slice(0, 14); api.setPref('names', nombres);
}
// Doble toque en el tablero (vista 2D): Todo → Grande → Muy grande → Todo
let ultToque = null;
function dobleToque(e) {
  if (modo3d || !P || !e.target.closest('#pzView') || e.target.closest('[data-pc],[data-dest]')) return;
  const ahora = Date.now(), u = ultToque; ultToque = { t: ahora, x: e.clientX, y: e.clientY };
  if (!u || ahora - u.t > 380 || Math.hypot(e.clientX - u.x, e.clientY - u.y) > 34) return;
  ultToque = null; zoomN = ZOOMS[(ZOOMS.indexOf(zoomN) + 1) % ZOOMS.length]; api.setPref('zoom', zoomN);
  const t = $('#pzTab'); if (t) t.style.width = zoom() * 100 + '%';
  api.aviso(zoomN === 1 ? 'Tablero: Todo' : zoomN === 1.4 ? 'Tablero: Grande' : 'Tablero: Muy grande');
  ultFoco = ''; pintarJuego();
}
function clic(e) {
  const pc = e.target.closest('[data-pc]');
  if (pc && P && P.phase === 'move' && !esCPU(P, actual(P)) && !P.anim) { const [c, i] = pc.dataset.pc.split(','), m = P.moves.find(m => m.c === c && m.i === +i); if (m) jugarMov(m); return; }
  const ds = e.target.closest('[data-dest]');
  if (ds && P && P.phase === 'move' && !esCPU(P, actual(P)) && !P.anim) { const m = P.moves.find(m => m.to === +ds.dataset.dest); if (m) jugarMov(m); return; }
  const b = e.target.closest('button'); if (!b) return;
  if (b.dataset.cfg) { const [c, t] = b.dataset.cfg.split(','); cfgSetup[c] = t === 'n' ? null : t; api.setPref('cfg', cfgSetup); return rSetup(); }
  if (b.dataset.vel) { api.setPref('vel', b.dataset.vel); return modo === 'setup' ? rSetup() : pintarJuego(); }
  const ac = b.dataset.ac;
  if (ac === 'start') {
    if (PC.filter(c => cfgSetup[c]).length < 2) return;
    iniciarPartida();
  } else if (ac === 'setup') nuevaSetup();
  else if (ac === 'aspecto') asp.abrir(); else if (ac === 'reglas') reglas();
}
function iniciarPartida() {
  const nm = {}; PC.forEach(c => { if (cfgSetup[c] && nombres[c] && nombres[c].trim()) nm[c] = nombres[c].trim().slice(0, 14); });
  clearTimeout(timer); clearInterval(ivDado); clearInterval(ivAnim); rodando = false;
  P = nuevaPartida(cfgSetup, nm, { salidaLibre: libre, parejas: parejas && PC.every(c => cfgSetup[c]) }); P.anim = false; modo = 'juego'; ultFoco = ''; guardar(); rJuego(); pintarJuego(); drive();
}
function reglas() { api.modal('Partxis', listaReglas()); }
